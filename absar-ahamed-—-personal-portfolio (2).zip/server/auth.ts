import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { findUserByEmail, findUserById, hasAnyAdminUser, toPublicUser } from './db.ts';
import type { PublicUser, UserRole } from './types.ts';

const FALLBACK_JWT_SECRET = crypto.randomBytes(32).toString('hex');

function getJwtSecret(): string {
  return process.env.JWT_SECRET?.trim() || FALLBACK_JWT_SECRET;
}

export function getEnvAdminConfig(): { email: string; password: string } | null {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase() || '';
  const password = process.env.ADMIN_PASSWORD?.trim() || '';
  if (email && password) {
    return { email, password };
  }
  return null;
}

export async function getAdminSetupStatus(): Promise<{
  configured: boolean;
  source: 'env' | 'claimed' | 'unclaimed';
}> {
  if (getEnvAdminConfig()) {
    return { configured: true, source: 'env' };
  }
  const hasClaimed = await hasAnyAdminUser();
  return hasClaimed
    ? { configured: true, source: 'claimed' }
    : { configured: false, source: 'unclaimed' };
}

export interface JwtPayload {
  sub: string;
  email: string;
  role: UserRole;
  name: string;
}

export interface AuthenticatedRequest extends Request {
  user?: PublicUser;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  if (!hash) return false;
  return bcrypt.compare(password, hash);
}

export function signJwtToken(user: PublicUser): string {
  const payload: JwtPayload = {
    sub: user.id,
    email: user.email,
    role: user.role,
    name: user.name,
  };
  return jwt.sign(payload, getJwtSecret(), { algorithm: 'HS256', expiresIn: '7d' });
}

export function verifyJwtToken(token: string): JwtPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret(), { algorithms: ['HS256'] });
    if (!decoded || typeof decoded !== 'object') return null;
    const sub = typeof decoded.sub === 'string' ? decoded.sub : '';
    const email = typeof decoded.email === 'string' ? decoded.email : '';
    const role = decoded.role === 'admin' ? 'admin' : 'user';
    const name = typeof decoded.name === 'string' ? decoded.name : '';
    if (!sub || !email) return null;
    return { sub, email, role, name };
  } catch {
    return null;
  }
}

export async function verifyLoginCredentials(
  email: string,
  password: string,
): Promise<PublicUser | null> {
  const normalized = email.trim().toLowerCase();
  const envAdmin = getEnvAdminConfig();

  if (envAdmin && normalized === envAdmin.email) {
    if (password === envAdmin.password) {
      const now = new Date().toISOString();
      return {
        id: 'env-admin',
        name: 'Platform Admin',
        email: envAdmin.email,
        role: 'admin',
        headline: 'Managing Editor & Administrator',
        bio: '',
        location: '',
        website: '',
        createdAt: now,
        updatedAt: now,
      };
    }
    return null;
  }

  const user = await findUserByEmail(normalized);
  if (!user || !user.passwordHash) {
    return null;
  }
  const matched = await verifyPassword(password, user.passwordHash);
  if (!matched) {
    return null;
  }
  return toPublicUser(user);
}

async function resolveUserFromPayload(payload: JwtPayload): Promise<PublicUser | null> {
  const envAdmin = getEnvAdminConfig();
  if (payload.sub === 'env-admin' && envAdmin && payload.email === envAdmin.email) {
    const now = new Date().toISOString();
    return {
      id: 'env-admin',
      name: 'Platform Admin',
      email: envAdmin.email,
      role: 'admin',
      headline: 'Managing Editor & Administrator',
      bio: '',
      location: '',
      website: '',
      createdAt: now,
      updatedAt: now,
    };
  }
  const dbUser = await findUserById(payload.sub);
  return dbUser ? toPublicUser(dbUser) : null;
}

export async function authenticateJwt(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  const token = header.slice(7).trim();
  const payload = verifyJwtToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Invalid or expired session token.' });
    return;
  }
  const user = await resolveUserFromPayload(payload);
  if (!user) {
    res.status(401).json({ error: 'Account no longer exists.' });
    return;
  }
  req.user = user;
  next();
}

export async function optionalJwt(
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  const header = req.headers.authorization;
  if (header && header.startsWith('Bearer ')) {
    const token = header.slice(7).trim();
    const payload = verifyJwtToken(token);
    if (payload) {
      const user = await resolveUserFromPayload(payload);
      if (user) {
        req.user = user;
      }
    }
  }
  next();
}

export function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (req.user.role !== 'admin') {
    res.status(403).json({ error: 'Administrator privileges required.' });
    return;
  }
  next();
}
