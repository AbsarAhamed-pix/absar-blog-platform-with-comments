import type { BlogPostRecord, CommentRecord, UserRecord } from './types.ts';

const now = Date.now();
const daysAgo = (days: number) => new Date(now - days * 86400_000).toISOString();

export const SEED_USERS: UserRecord[] = [
  {
    id: 'author-editorial-1',
    name: 'Meera Sundaram',
    email: 'meera.editorial@vellumjournal.local',
    passwordHash: '',
    role: 'user',
    headline: 'Systems Architect & Technical Writer',
    bio: 'Writing on distributed backends, pragmatic API boundaries, and enduring software design.',
    location: 'Chennai, India',
    website: '',
    isSeedAuthor: true,
    createdAt: daysAgo(45),
    updatedAt: daysAgo(45),
  },
  {
    id: 'author-editorial-2',
    name: 'Karthik Rajagopal',
    email: 'karthik.editorial@vellumjournal.local',
    passwordHash: '',
    role: 'user',
    headline: 'Design Technologist & Frontend Lead',
    bio: 'Exploring typographic grids, accessible components, and calm user interfaces.',
    location: 'Bengaluru, India',
    website: '',
    isSeedAuthor: true,
    createdAt: daysAgo(40),
    updatedAt: daysAgo(40),
  },
  {
    id: 'author-editorial-3',
    name: 'Rohan Kulkarni',
    email: 'rohan.editorial@vellumjournal.local',
    passwordHash: '',
    role: 'user',
    headline: 'Database & Storage Engineer',
    bio: 'Focusing on query planning, indexing strategies, and reliable transaction patterns.',
    location: 'Pune, India',
    website: '',
    isSeedAuthor: true,
    createdAt: daysAgo(35),
    updatedAt: daysAgo(35),
  },
];

export const SEED_POSTS: BlogPostRecord[] = [
  {
    id: 'post-arch-01',
    title: 'Designing Calm Full-Stack Architectures That Survive Growth',
    slug: 'designing-calm-full-stack-architectures',
    excerpt:
      'Why clear module boundaries, explicit validation layers, and predictable REST contracts outlast trendy abstractions in growing engineering teams.',
    content: `Every software system begins with good intentions and a clean directory tree. Six months later, business logic has leaked into route handlers, validation rules are duplicated across client forms and database models, and nobody is quite sure which layer owns authorization.

The antidote is not a heavier framework—it is calm, disciplined separation of responsibilities. When an Express API treats request parsing, identity verification, and persistence as distinct stages, each part becomes straightforward to reason about and test in isolation.

Start by establishing strict trust boundaries. Never trust client-supplied identifiers, role fields, or price calculations. Validate every incoming payload against an explicit schema before it touches a database query, and sanitize dynamic URLs before rendering them in templates.

Equally important is keeping your data model honest. Relational links between users, authored essays, and threaded comments should remain consistent even when posts are edited or removed. A clean codebase feels quiet: every function has a single clear job, errors surface with helpful context, and new contributors can trace a request from button click to storage in under two minutes.`,
    coverImage: '/src/assets/images/blog_cover_architecture_1795522143267.jpg',
    category: 'Architecture',
    tags: ['architecture', 'nodejs', 'rest-api', 'clean-code'],
    authorId: 'author-editorial-1',
    authorName: 'Meera Sundaram',
    authorHeadline: 'Systems Architect & Technical Writer',
    status: 'published',
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: daysAgo(2),
    createdAt: daysAgo(3),
    updatedAt: daysAgo(2),
  },
  {
    id: 'post-sys-02',
    title: 'Authentication Boundaries: Why Ownership Checks Belong on the Server',
    slug: 'authentication-boundaries-ownership-checks',
    excerpt:
      'Understanding JWT verification, role-based access control, and why hiding an Edit button in React is never a substitute for server-side authorization.',
    content: `Frontend interfaces should adapt to the signed-in user: a reader sees comment boxes, an author sees edit controls on their own essays, and a moderator sees platform review tools. Yet hiding a button in the browser only improves user experience—it provides zero security on its own.

Any HTTP client can send a direct request to your update or delete endpoints. That is why every mutating route must resolve the caller from a verified cryptographic token, load the target resource from storage, and explicitly confirm ownership or administrator privileges before applying changes.

Password handling follows the same principle of non-negotiable server discipline. Passwords must be hashed with a slow, salted algorithm like bcrypt before persistence, and password hashes must never leave the backend in API responses.

When authentication middleware, role guards, and resource ownership checks are composed cleanly, security stops feeling like an afterthought and becomes part of the natural architecture of your application.`,
    coverImage: '/src/assets/images/blog_cover_systems_1795522143794.jpg',
    category: 'Engineering',
    tags: ['security', 'jwt', 'bcrypt', 'express'],
    authorId: 'author-editorial-1',
    authorName: 'Meera Sundaram',
    authorHeadline: 'Systems Architect & Technical Writer',
    status: 'published',
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: daysAgo(6),
    createdAt: daysAgo(7),
    updatedAt: daysAgo(6),
  },
  {
    id: 'post-type-03',
    title: 'Editorial Typography on the Web: Measure, Rhythm, and Restraint',
    slug: 'editorial-typography-measure-rhythm',
    excerpt:
      'How constraining line length to 65–75 characters, pairing serif headlines with legible sans body text, and removing decorative clutter transforms reading comfort.',
    content: `Reading long-form technical writing on a screen should feel effortless. Too often, modern web templates stretch paragraphs edge-to-edge across 1400-pixel monitors or surround every metadata label in brightly colored pill capsules that compete for eye focus.

Classic print typography solved readability centuries ago. By constraining prose columns to roughly 68 characters per line and maintaining generous vertical line height, readers track seamlessly from the end of one line to the start of the next without fatigue.

Pair an expressive editorial serif for titles with a crisp, neutral sans-serif for navigation and interface controls, and keep dates, categories, and tags as quiet unboxed text separated by typographic middots.

When visual noise disappears, the author's ideas take center stage—and both light paper modes and low-glare dark modes remain equally inviting.`,
    coverImage: '/src/assets/images/blog_cover_typography_1795522144580.jpg',
    category: 'Design Systems',
    tags: ['typography', 'ui-design', 'accessibility', 'css'],
    authorId: 'author-editorial-2',
    authorName: 'Karthik Rajagopal',
    authorHeadline: 'Design Technologist & Frontend Lead',
    status: 'published',
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: daysAgo(11),
    createdAt: daysAgo(12),
    updatedAt: daysAgo(11),
  },
  {
    id: 'post-db-04',
    title: 'Modeling Blog Posts and Threaded Comments in MongoDB',
    slug: 'modeling-posts-and-comments-mongodb',
    excerpt:
      'Choosing between embedded arrays and referenced collections for scalable comment threads, moderation flags, and author queries.',
    content: `One of the first architectural decisions in a MongoDB-backed publishing platform is whether comments belong embedded inside the post document or in their own collection.

For small prototypes, embedding looks tempting—a single read fetches the article and its comments together. However, as discussions grow, post documents risk hitting size limits, editing a single nested comment becomes awkward, and platform-wide comment moderation requires scanning every post.

Storing Comments in a dedicated collection linked by postId and userId solves all three problems cleanly. Indexes on postId and createdAt make fetching article discussions fast, while a parentCommentId field supports natural threaded replies without deep recursive writes.

Best of all, writers can inspect recent comments received across all their articles, and moderators can review or hide individual comments independently of the underlying essay.`,
    coverImage: '/src/assets/images/blog_cover_databases_1795522144590.jpg',
    category: 'Databases',
    tags: ['mongodb', 'schema-design', 'indexing', 'backend'],
    authorId: 'author-editorial-3',
    authorName: 'Rohan Kulkarni',
    authorHeadline: 'Database & Storage Engineer',
    status: 'published',
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: daysAgo(16),
    createdAt: daysAgo(17),
    updatedAt: daysAgo(16),
  },
  {
    id: 'post-career-05',
    title: 'Writing in Public as an Engineering Student: Notes from Second Year',
    slug: 'writing-in-public-engineering-student',
    excerpt:
      'Why documenting bugs you solved, architectural trade-offs, and internship projects builds deeper mastery than passive tutorial watching.',
    content: `Most computer science students wait until they feel like experts before publishing their first technical article. In practice, writing is the fastest way to discover what you truly understand—and where your mental model still has gaps.

Start small. When you finally debug a tricky state synchronization issue or wire up JWT authentication for the first time, write down the problem statement, the failed hypotheses, and the clean solution you landed on.

Future readers facing the exact same error at midnight will appreciate your clarity, and future interviewers will see not just finished repositories, but how you think through engineering constraints.

Treat your drafts folder as a laboratory: jot rough outlines during labs, refine them with diagrams and concrete examples over the weekend, and publish when the explanation would have helped you a week ago.`,
    coverImage: '/src/assets/images/blog_cover_craft_1795522144973.jpg',
    category: 'Career',
    tags: ['learning', 'engineering-craft', 'writing', 'students'],
    authorId: 'author-editorial-2',
    authorName: 'Karthik Rajagopal',
    authorHeadline: 'Design Technologist & Frontend Lead',
    status: 'published',
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: daysAgo(22),
    createdAt: daysAgo(23),
    updatedAt: daysAgo(22),
  },
];

export const SEED_COMMENTS: CommentRecord[] = [
  {
    id: 'cmt-seed-01',
    postId: 'post-arch-01',
    userId: 'author-editorial-2',
    authorName: 'Karthik Rajagopal',
    authorRole: 'user',
    parentCommentId: null,
    content:
      'Keeping validation and database persistence separate saved our team countless hours during our API refactor last quarter.',
    isModerated: false,
    moderationNote: '',
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
  },
  {
    id: 'cmt-seed-02',
    postId: 'post-arch-01',
    userId: 'author-editorial-1',
    authorName: 'Meera Sundaram',
    authorRole: 'user',
    parentCommentId: 'cmt-seed-01',
    content:
      'Agreed—having a dedicated validation module also makes automated endpoint testing much cleaner.',
    isModerated: false,
    moderationNote: '',
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
  },
  {
    id: 'cmt-seed-03',
    postId: 'post-db-04',
    userId: 'author-editorial-1',
    authorName: 'Meera Sundaram',
    authorRole: 'user',
    parentCommentId: null,
    content:
      'Separate comment collections also make cascade deletion and moderation queues straightforward to maintain.',
    isModerated: false,
    moderationNote: '',
    createdAt: daysAgo(10),
    updatedAt: daysAgo(10),
  },
];
