import type { BlogCategory, ModerationStatus, PostStatus } from './types.ts';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const VALID_CATEGORIES = new Set<BlogCategory>([
  'Engineering',
  'Architecture',
  'Design Systems',
  'Databases',
  'Career',
]);

const VALID_POST_STATUSES = new Set<PostStatus>(['draft', 'published']);
const VALID_MODERATION_STATUSES = new Set<ModerationStatus>(['approved', 'flagged']);

export function hasNoSqlOperatorKey(value: unknown): boolean {
  if (!value || typeof value !== 'object') {
    return false;
  }
  if (Array.isArray(value)) {
    return value.some((item) => hasNoSqlOperatorKey(item));
  }
  for (const [key, val] of Object.entries(value)) {
    if (key.startsWith('$') || key.includes('.')) {
      return true;
    }
    if (hasNoSqlOperatorKey(val)) {
      return true;
    }
  }
  return false;
}

export function cleanText(value: unknown, maxLength: number): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().slice(0, maxLength);
}

export function sanitizeSafeUrl(
  value: unknown,
  options: { allowLocalAssets?: boolean } = {},
): string {
  if (typeof value !== 'string') {
    return '';
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return '';
  }
  if (options.allowLocalAssets && trimmed.startsWith('/src/assets/')) {
    return trimmed.slice(0, 500);
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.toString().slice(0, 500);
    }
    return '';
  } catch {
    return '';
  }
}

export function validateRegisterInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { name: string; email: string; password: string; headline: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid registration payload.' };
  }
  const raw = body as Record<string, unknown>;
  const name = cleanText(raw.name, 80);
  const email = cleanText(raw.email, 150).toLowerCase();
  const password = typeof raw.password === 'string' ? raw.password : '';
  const headline = cleanText(raw.headline, 120) || 'Contributor';

  if (name.length < 2) {
    return { ok: false, error: 'Full name must be at least 2 characters.' };
  }
  if (!EMAIL_REGEX.test(email)) {
    return { ok: false, error: 'Please enter a valid email address.' };
  }
  if (password.length < 6 || password.length > 128) {
    return { ok: false, error: 'Password must be between 6 and 128 characters.' };
  }
  return { ok: true, data: { name, email, password, headline } };
}

export function validateLoginInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { email: string; password: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid login payload.' };
  }
  const raw = body as Record<string, unknown>;
  const email = cleanText(raw.email, 150).toLowerCase();
  const password = typeof raw.password === 'string' ? raw.password : '';

  if (!EMAIL_REGEX.test(email)) {
    return { ok: false, error: 'Please enter a valid email address.' };
  }
  if (!password) {
    return { ok: false, error: 'Password is required.' };
  }
  return { ok: true, data: { email, password } };
}

export function validateProfileUpdateInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { name: string; headline: string; bio: string; location: string; website: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid profile payload.' };
  }
  const raw = body as Record<string, unknown>;
  const name = cleanText(raw.name, 80);
  const headline = cleanText(raw.headline, 120);
  const bio = cleanText(raw.bio, 500);
  const location = cleanText(raw.location, 80);
  const websiteRaw = cleanText(raw.website, 240);
  const website = websiteRaw ? sanitizeSafeUrl(websiteRaw) : '';

  if (name.length < 2) {
    return { ok: false, error: 'Display name must be at least 2 characters.' };
  }
  if (websiteRaw && !website) {
    return { ok: false, error: 'Website must be a valid http:// or https:// URL.' };
  }
  return {
    ok: true,
    data: { name, headline, bio, location, website },
  };
}

export function validatePostInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: {
    title: string;
    excerpt: string;
    content: string;
    coverImage: string;
    category: BlogCategory;
    tags: string[];
    status: PostStatus;
  };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid blog post payload.' };
  }
  const raw = body as Record<string, unknown>;
  const title = cleanText(raw.title, 160);
  const content = typeof raw.content === 'string' ? raw.content.trim().slice(0, 30000) : '';
  const excerptRaw = cleanText(raw.excerpt, 360);
  const category = cleanText(raw.category, 40) as BlogCategory;
  const status = (cleanText(raw.status, 20) || 'published') as PostStatus;
  const coverRaw = cleanText(raw.coverImage, 500);
  const coverImage =
    sanitizeSafeUrl(coverRaw, { allowLocalAssets: true }) ||
    '/src/assets/images/blog_cover_architecture_1795522143267.jpg';

  if (title.length < 4) {
    return { ok: false, error: 'Blog title must be at least 4 characters.' };
  }
  if (content.length < 20) {
    return { ok: false, error: 'Blog content must be at least 20 characters.' };
  }
  if (!VALID_CATEGORIES.has(category)) {
    return {
      ok: false,
      error: 'Category must be Engineering, Architecture, Design Systems, Databases, or Career.',
    };
  }
  if (!VALID_POST_STATUSES.has(status)) {
    return { ok: false, error: 'Status must be draft or published.' };
  }
  if (coverRaw && !sanitizeSafeUrl(coverRaw, { allowLocalAssets: true })) {
    return {
      ok: false,
      error: 'Cover image must be a valid http(s) URL or studio cover asset.',
    };
  }

  let tags: string[] = [];
  if (Array.isArray(raw.tags)) {
    tags = raw.tags
      .map((t) => cleanText(t, 32).toLowerCase().replace(/^#+/, ''))
      .filter(Boolean)
      .slice(0, 8);
  } else if (typeof raw.tags === 'string') {
    tags = raw.tags
      .split(',')
      .map((t) => t.trim().toLowerCase().replace(/^#+/, '').slice(0, 32))
      .filter(Boolean)
      .slice(0, 8);
  }
  const uniqueTags = Array.from(new Set(tags));

  const plainSnippet = content.replace(/\s+/g, ' ').slice(0, 180);
  const excerpt = excerptRaw || (plainSnippet.length === 180 ? `${plainSnippet}...` : plainSnippet);

  return {
    ok: true,
    data: {
      title,
      excerpt,
      content,
      coverImage,
      category,
      tags: uniqueTags,
      status,
    },
  };
}

export function validateCommentInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { content: string; parentCommentId: string | null };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid comment payload.' };
  }
  const raw = body as Record<string, unknown>;
  const content = typeof raw.content === 'string' ? raw.content.trim().slice(0, 2000) : '';
  const parentRaw = cleanText(raw.parentCommentId, 80);

  if (content.length < 2) {
    return { ok: false, error: 'Comment must be at least 2 characters.' };
  }

  return {
    ok: true,
    data: {
      content,
      parentCommentId: parentRaw || null,
    },
  };
}

export function validatePostModerationInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { moderationStatus: ModerationStatus; status?: PostStatus; moderationNote: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid moderation payload.' };
  }
  const raw = body as Record<string, unknown>;
  const moderationStatus = cleanText(raw.moderationStatus, 30) as ModerationStatus;
  const statusRaw = cleanText(raw.status, 20);
  const moderationNote = cleanText(raw.moderationNote, 240);

  if (!VALID_MODERATION_STATUSES.has(moderationStatus)) {
    return { ok: false, error: 'Moderation status must be approved or flagged.' };
  }
  if (statusRaw && !VALID_POST_STATUSES.has(statusRaw as PostStatus)) {
    return { ok: false, error: 'Post status must be draft or published.' };
  }
  return {
    ok: true,
    data: {
      moderationStatus,
      status: statusRaw ? (statusRaw as PostStatus) : undefined,
      moderationNote,
    },
  };
}

export function validateCommentModerationInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { isModerated: boolean; moderationNote: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid comment moderation payload.' };
  }
  const raw = body as Record<string, unknown>;
  if (typeof raw.isModerated !== 'boolean') {
    return { ok: false, error: 'isModerated boolean flag is required.' };
  }
  const moderationNote = cleanText(raw.moderationNote, 240);
  return {
    ok: true,
    data: {
      isModerated: raw.isModerated,
      moderationNote,
    },
  };
}
