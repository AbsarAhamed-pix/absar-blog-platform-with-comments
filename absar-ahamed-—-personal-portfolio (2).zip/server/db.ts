import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import mongoose, { Schema, type Model } from 'mongoose';
import { SEED_COMMENTS, SEED_POSTS, SEED_USERS } from './seedData.ts';
import type {
  BlogCategory,
  BlogPostRecord,
  BlogPostWithMeta,
  BlogStoreSnapshot,
  CommentRecord,
  ModerationStatus,
  PostStatus,
  PublicUser,
  UserRecord,
  UserRole,
} from './types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');
const STORE_FILE = path.join(DATA_DIR, 'blog-store.json');

interface UserDoc {
  userId: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  headline: string;
  bio: string;
  location: string;
  website: string;
  isSeedAuthor: boolean;
  createdAt: string;
  updatedAt: string;
}

interface BlogPostDoc {
  postId: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: BlogCategory;
  tags: string[];
  authorId: string;
  authorName: string;
  authorHeadline: string;
  status: PostStatus;
  moderationStatus: ModerationStatus;
  moderationNote: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface CommentDoc {
  commentId: string;
  postId: string;
  userId: string;
  authorName: string;
  authorRole: UserRole;
  parentCommentId: string | null;
  content: string;
  isModerated: boolean;
  moderationNote: string;
  createdAt: string;
  updatedAt: string;
}

const BlogUserSchema = new Schema<UserDoc>(
  {
    userId: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, index: true },
    passwordHash: { type: String, default: '' },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    headline: { type: String, default: 'Contributor' },
    bio: { type: String, default: '' },
    location: { type: String, default: '' },
    website: { type: String, default: '' },
    isSeedAuthor: { type: Boolean, default: false },
    createdAt: { type: String, required: true },
    updatedAt: { type: String, required: true },
  },
  { collection: 'blog_users' },
);

const BlogPostSchema = new Schema<BlogPostDoc>(
  {
    postId: { type: String, required: true, unique: true, index: true },
    title: { type: String, required: true },
    slug: { type: String, required: true, index: true },
    excerpt: { type: String, required: true },
    content: { type: String, required: true },
    coverImage: { type: String, required: true },
    category: {
      type: String,
      enum: ['Engineering', 'Architecture', 'Design Systems', 'Databases', 'Career'],
      required: true,
    },
    tags: { type: [String], default: [] },
    authorId: { type: String, required: true, index: true },
    authorName: { type: String, required: true },
    authorHeadline: { type: String, default: '' },
    status: { type: String, enum: ['draft', 'published'], default: 'published', index: true },
    moderationStatus: { type: String, enum: ['approved', 'flagged'], default: 'approved' },
    moderationNote: { type: String, default: '' },
    publishedAt: { type: String, default: null },
    createdAt: { type: String, required: true },
    updatedAt: { type: String, required: true },
  },
  { collection: 'blog_posts' },
);

const BlogCommentSchema = new Schema<CommentDoc>(
  {
    commentId: { type: String, required: true, unique: true, index: true },
    postId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    authorName: { type: String, required: true },
    authorRole: { type: String, enum: ['user', 'admin'], default: 'user' },
    parentCommentId: { type: String, default: null },
    content: { type: String, required: true },
    isModerated: { type: Boolean, default: false },
    moderationNote: { type: String, default: '' },
    createdAt: { type: String, required: true },
    updatedAt: { type: String, required: true },
  },
  { collection: 'blog_comments' },
);

const BlogUserModel: Model<UserDoc> =
  (mongoose.models.BlogUser as Model<UserDoc>) ||
  mongoose.model<UserDoc>('BlogUser', BlogUserSchema);

const BlogPostModel: Model<BlogPostDoc> =
  (mongoose.models.BlogPost as Model<BlogPostDoc>) ||
  mongoose.model<BlogPostDoc>('BlogPost', BlogPostSchema);

const BlogCommentModel: Model<CommentDoc> =
  (mongoose.models.BlogComment as Model<CommentDoc>) ||
  mongoose.model<CommentDoc>('BlogComment', BlogCommentSchema);

let dbMode: 'mongodb' | 'local-store' = 'local-store';
let writeQueue: Promise<unknown> = Promise.resolve();

function serializeWrite<T>(task: () => Promise<T>): Promise<T> {
  const next = writeQueue.then(task, task);
  writeQueue = next.catch(() => undefined);
  return next;
}

export function getDatabaseMode(): 'mongodb' | 'local-store' {
  return dbMode;
}

export function toPublicUser(user: UserRecord): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    headline: user.headline,
    bio: user.bio,
    location: user.location,
    website: user.website,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

function estimateReadMinutes(content: string): number {
  const words = content.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(words / 180));
}

function makeSlug(title: string): string {
  const base = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 70);
  return base || `post-${crypto.randomBytes(3).toString('hex')}`;
}

function mapUserDoc(doc: UserDoc): UserRecord {
  return {
    id: doc.userId,
    name: doc.name,
    email: doc.email,
    passwordHash: doc.passwordHash,
    role: doc.role,
    headline: doc.headline,
    bio: doc.bio,
    location: doc.location,
    website: doc.website,
    isSeedAuthor: doc.isSeedAuthor,
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

function mapPostDoc(doc: BlogPostDoc): BlogPostRecord {
  return {
    id: doc.postId,
    title: doc.title,
    slug: doc.slug,
    excerpt: doc.excerpt,
    content: doc.content,
    coverImage: doc.coverImage,
    category: doc.category,
    tags: [...(doc.tags || [])],
    authorId: doc.authorId,
    authorName: doc.authorName,
    authorHeadline: doc.authorHeadline,
    status: doc.status,
    moderationStatus: doc.moderationStatus,
    moderationNote: doc.moderationNote || '',
    publishedAt: doc.publishedAt,
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

function mapCommentDoc(doc: CommentDoc): CommentRecord {
  return {
    id: doc.commentId,
    postId: doc.postId,
    userId: doc.userId,
    authorName: doc.authorName,
    authorRole: doc.authorRole,
    parentCommentId: doc.parentCommentId,
    content: doc.content,
    isModerated: Boolean(doc.isModerated),
    moderationNote: doc.moderationNote || '',
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

async function readLocalStore(): Promise<BlogStoreSnapshot> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    const raw = await fs.readFile(STORE_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<BlogStoreSnapshot>;
    return {
      users: Array.isArray(parsed.users) ? parsed.users : [...SEED_USERS],
      posts: Array.isArray(parsed.posts) ? parsed.posts : [...SEED_POSTS],
      comments: Array.isArray(parsed.comments) ? parsed.comments : [...SEED_COMMENTS],
    };
  } catch {
    const initial: BlogStoreSnapshot = {
      users: [...SEED_USERS],
      posts: [...SEED_POSTS],
      comments: [...SEED_COMMENTS],
    };
    await writeLocalStore(initial);
    return initial;
  }
}

async function writeLocalStore(snapshot: BlogStoreSnapshot): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmpFile = path.join(DATA_DIR, `blog-store.${crypto.randomUUID()}.tmp`);
  await fs.writeFile(tmpFile, JSON.stringify(snapshot, null, 2), 'utf8');
  await fs.rename(tmpFile, STORE_FILE);
}

export async function initDatabase(): Promise<void> {
  const mongoUri = process.env.MONGODB_URI?.trim();
  if (mongoUri) {
    try {
      await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 5000 });
      dbMode = 'mongodb';
      const postCount = await BlogPostModel.countDocuments();
      if (postCount === 0) {
        for (const u of SEED_USERS) {
          const exists = await BlogUserModel.findOne({ userId: u.id }).lean();
          if (!exists) {
            await BlogUserModel.create({
              userId: u.id,
              name: u.name,
              email: u.email,
              passwordHash: u.passwordHash,
              role: u.role,
              headline: u.headline,
              bio: u.bio,
              location: u.location,
              website: u.website,
              isSeedAuthor: Boolean(u.isSeedAuthor),
              createdAt: u.createdAt,
              updatedAt: u.updatedAt,
            });
          }
        }
        await BlogPostModel.insertMany(
          SEED_POSTS.map((p) => ({
            postId: p.id,
            title: p.title,
            slug: p.slug,
            excerpt: p.excerpt,
            content: p.content,
            coverImage: p.coverImage,
            category: p.category,
            tags: p.tags,
            authorId: p.authorId,
            authorName: p.authorName,
            authorHeadline: p.authorHeadline,
            status: p.status,
            moderationStatus: p.moderationStatus,
            moderationNote: p.moderationNote,
            publishedAt: p.publishedAt,
            createdAt: p.createdAt,
            updatedAt: p.updatedAt,
          })),
        );
        await BlogCommentModel.insertMany(
          SEED_COMMENTS.map((c) => ({
            commentId: c.id,
            postId: c.postId,
            userId: c.userId,
            authorName: c.authorName,
            authorRole: c.authorRole,
            parentCommentId: c.parentCommentId,
            content: c.content,
            isModerated: c.isModerated,
            moderationNote: c.moderationNote,
            createdAt: c.createdAt,
            updatedAt: c.updatedAt,
          })),
        );
      }
      return;
    } catch (err) {
      console.warn(
        '[db] MongoDB connection failed, falling back to persistent local store:',
        (err as Error).message,
      );
    }
  }

  dbMode = 'local-store';
  await readLocalStore();
}

// ==================== USER QUERIES ====================

export async function findUserByEmail(email: string): Promise<UserRecord | null> {
  const normalized = email.trim().toLowerCase();
  if (dbMode === 'mongodb') {
    const doc = await BlogUserModel.findOne({ email: normalized }).lean();
    return doc ? mapUserDoc(doc) : null;
  }
  const store = await readLocalStore();
  return store.users.find((u) => u.email.toLowerCase() === normalized) ?? null;
}

export async function findUserById(id: string): Promise<UserRecord | null> {
  if (dbMode === 'mongodb') {
    const doc = await BlogUserModel.findOne({ userId: id }).lean();
    return doc ? mapUserDoc(doc) : null;
  }
  const store = await readLocalStore();
  return store.users.find((u) => u.id === id) ?? null;
}

export async function hasAnyAdminUser(): Promise<boolean> {
  if (dbMode === 'mongodb') {
    const count = await BlogUserModel.countDocuments({ role: 'admin' });
    return count > 0;
  }
  const store = await readLocalStore();
  return store.users.some((u) => u.role === 'admin');
}

export async function createUser(input: {
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  headline: string;
}): Promise<UserRecord> {
  const now = new Date().toISOString();
  const record: UserRecord = {
    id: `usr-${crypto.randomUUID().slice(0, 8)}`,
    name: input.name,
    email: input.email.toLowerCase(),
    passwordHash: input.passwordHash,
    role: input.role,
    headline: input.headline || (input.role === 'admin' ? 'Platform Editor' : 'Contributor'),
    bio: '',
    location: '',
    website: '',
    createdAt: now,
    updatedAt: now,
  };

  if (dbMode === 'mongodb') {
    await BlogUserModel.create({
      userId: record.id,
      name: record.name,
      email: record.email,
      passwordHash: record.passwordHash,
      role: record.role,
      headline: record.headline,
      bio: record.bio,
      location: record.location,
      website: record.website,
      isSeedAuthor: false,
      createdAt: record.createdAt,
      updatedAt: record.updatedAt,
    });
    return record;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    store.users.push(record);
    await writeLocalStore(store);
    return record;
  });
}

export async function updateUserProfile(
  userId: string,
  updates: { name: string; headline: string; bio: string; location: string; website: string },
): Promise<UserRecord | null> {
  const now = new Date().toISOString();

  if (dbMode === 'mongodb') {
    const updated = await BlogUserModel.findOneAndUpdate(
      { userId },
      {
        $set: {
          name: updates.name,
          headline: updates.headline,
          bio: updates.bio,
          location: updates.location,
          website: updates.website,
          updatedAt: now,
        },
      },
      { new: true },
    ).lean();
    if (!updated) return null;
    await BlogPostModel.updateMany(
      { authorId: userId },
      { $set: { authorName: updates.name, authorHeadline: updates.headline } },
    );
    await BlogCommentModel.updateMany(
      { userId },
      { $set: { authorName: updates.name } },
    );
    return mapUserDoc(updated);
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const idx = store.users.findIndex((u) => u.id === userId);
    if (idx === -1) return null;
    store.users[idx] = {
      ...store.users[idx],
      ...updates,
      updatedAt: now,
    };
    store.posts = store.posts.map((p) =>
      p.authorId === userId
        ? { ...p, authorName: updates.name, authorHeadline: updates.headline }
        : p,
    );
    store.comments = store.comments.map((c) =>
      c.userId === userId ? { ...c, authorName: updates.name } : c,
    );
    await writeLocalStore(store);
    return store.users[idx];
  });
}

// ==================== BLOG POST QUERIES ====================

export async function listPosts(filters: {
  search?: string;
  category?: string;
  authorId?: string;
  tag?: string;
  sort?: string;
  includeDraftsForAuthorId?: string;
  includeAllForAdmin?: boolean;
}): Promise<BlogPostWithMeta[]> {
  let posts: BlogPostRecord[];
  let comments: CommentRecord[];

  if (dbMode === 'mongodb') {
    const [pDocs, cDocs] = await Promise.all([
      BlogPostModel.find({}).lean(),
      BlogCommentModel.find({}).lean(),
    ]);
    posts = pDocs.map(mapPostDoc);
    comments = cDocs.map(mapCommentDoc);
  } else {
    const store = await readLocalStore();
    posts = [...store.posts];
    comments = [...store.comments];
  }

  const commentCounts = new Map<string, number>();
  for (const c of comments) {
    if (!c.isModerated) {
      commentCounts.set(c.postId, (commentCounts.get(c.postId) ?? 0) + 1);
    }
  }

  let filtered = posts.filter((p) => {
    if (filters.includeAllForAdmin) {
      return true;
    }
    if (filters.includeDraftsForAuthorId) {
      return p.authorId === filters.includeDraftsForAuthorId;
    }
    return p.status === 'published' && p.moderationStatus !== 'flagged';
  });

  if (filters.category && filters.category !== 'All') {
    filtered = filtered.filter((p) => p.category === filters.category);
  }

  if (filters.authorId && filters.authorId !== 'all') {
    filtered = filtered.filter((p) => p.authorId === filters.authorId);
  }

  if (filters.tag) {
    const needleTag = filters.tag.toLowerCase();
    filtered = filtered.filter((p) => p.tags.some((t) => t.toLowerCase() === needleTag));
  }

  if (filters.search) {
    const q = filters.search.toLowerCase();
    filtered = filtered.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.excerpt.toLowerCase().includes(q) ||
        p.content.toLowerCase().includes(q) ||
        p.authorName.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q)),
    );
  }

  filtered.sort((a, b) => {
    const dateA = new Date(a.publishedAt || a.createdAt).getTime();
    const dateB = new Date(b.publishedAt || b.createdAt).getTime();
    return filters.sort === 'oldest' ? dateA - dateB : dateB - dateA;
  });

  return filtered.map((p) => ({
    ...p,
    commentCount: commentCounts.get(p.id) ?? 0,
    readMinutes: estimateReadMinutes(p.content),
  }));
}

export async function listPublishedAuthors(): Promise<Array<{ id: string; name: string }>> {
  let posts: BlogPostRecord[];
  if (dbMode === 'mongodb') {
    const docs = await BlogPostModel.find({
      status: 'published',
      moderationStatus: 'approved',
    }).lean();
    posts = docs.map(mapPostDoc);
  } else {
    const store = await readLocalStore();
    posts = store.posts.filter(
      (p) => p.status === 'published' && p.moderationStatus !== 'flagged',
    );
  }

  const authorMap = new Map<string, string>();
  for (const p of posts) {
    if (!authorMap.has(p.authorId)) {
      authorMap.set(p.authorId, p.authorName);
    }
  }
  return Array.from(authorMap.entries())
    .map(([id, name]) => ({ id, name }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export async function findPostById(id: string): Promise<BlogPostWithMeta | null> {
  if (dbMode === 'mongodb') {
    const doc = await BlogPostModel.findOne({ postId: id }).lean();
    if (!doc) return null;
    const count = await BlogCommentModel.countDocuments({ postId: id, isModerated: false });
    const post = mapPostDoc(doc);
    return {
      ...post,
      commentCount: count,
      readMinutes: estimateReadMinutes(post.content),
    };
  }
  const store = await readLocalStore();
  const post = store.posts.find((p) => p.id === id);
  if (!post) return null;
  const count = store.comments.filter((c) => c.postId === id && !c.isModerated).length;
  return {
    ...post,
    commentCount: count,
    readMinutes: estimateReadMinutes(post.content),
  };
}

export async function createPost(input: {
  title: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: BlogCategory;
  tags: string[];
  status: PostStatus;
  author: PublicUser;
}): Promise<BlogPostWithMeta> {
  const now = new Date().toISOString();
  const id = `post-${crypto.randomUUID().slice(0, 8)}`;
  const record: BlogPostRecord = {
    id,
    title: input.title,
    slug: `${makeSlug(input.title)}-${id.slice(-4)}`,
    excerpt: input.excerpt,
    content: input.content,
    coverImage: input.coverImage,
    category: input.category,
    tags: input.tags,
    authorId: input.author.id,
    authorName: input.author.name,
    authorHeadline: input.author.headline || 'Contributor',
    status: input.status,
    moderationStatus: 'approved',
    moderationNote: '',
    publishedAt: input.status === 'published' ? now : null,
    createdAt: now,
    updatedAt: now,
  };

  if (dbMode === 'mongodb') {
    await BlogPostModel.create({
      postId: record.id,
      title: record.title,
      slug: record.slug,
      excerpt: record.excerpt,
      content: record.content,
      coverImage: record.coverImage,
      category: record.category,
      tags: record.tags,
      authorId: record.authorId,
      authorName: record.authorName,
      authorHeadline: record.authorHeadline,
      status: record.status,
      moderationStatus: record.moderationStatus,
      moderationNote: record.moderationNote,
      publishedAt: record.publishedAt,
      createdAt: record.createdAt,
      updatedAt: record.updatedAt,
    });
    return { ...record, commentCount: 0, readMinutes: estimateReadMinutes(record.content) };
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    store.posts.unshift(record);
    await writeLocalStore(store);
    return { ...record, commentCount: 0, readMinutes: estimateReadMinutes(record.content) };
  });
}

export async function updatePost(
  postId: string,
  updates: {
    title: string;
    excerpt: string;
    content: string;
    coverImage: string;
    category: BlogCategory;
    tags: string[];
    status: PostStatus;
  },
): Promise<BlogPostWithMeta | null> {
  const now = new Date().toISOString();

  if (dbMode === 'mongodb') {
    const existing = await BlogPostModel.findOne({ postId }).lean();
    if (!existing) return null;
    const publishedAt =
      updates.status === 'published'
        ? existing.publishedAt || now
        : existing.publishedAt;

    const updated = await BlogPostModel.findOneAndUpdate(
      { postId },
      {
        $set: {
          title: updates.title,
          slug: `${makeSlug(updates.title)}-${postId.slice(-4)}`,
          excerpt: updates.excerpt,
          content: updates.content,
          coverImage: updates.coverImage,
          category: updates.category,
          tags: updates.tags,
          status: updates.status,
          publishedAt,
          updatedAt: now,
        },
      },
      { new: true },
    ).lean();
    if (!updated) return null;
    const commentCount = await BlogCommentModel.countDocuments({ postId, isModerated: false });
    const post = mapPostDoc(updated);
    return {
      ...post,
      commentCount,
      readMinutes: estimateReadMinutes(post.content),
    };
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const idx = store.posts.findIndex((p) => p.id === postId);
    if (idx === -1) return null;
    const existing = store.posts[idx];
    const publishedAt =
      updates.status === 'published'
        ? existing.publishedAt || now
        : existing.publishedAt;

    const nextPost: BlogPostRecord = {
      ...existing,
      title: updates.title,
      slug: `${makeSlug(updates.title)}-${postId.slice(-4)}`,
      excerpt: updates.excerpt,
      content: updates.content,
      coverImage: updates.coverImage,
      category: updates.category,
      tags: updates.tags,
      status: updates.status,
      publishedAt,
      updatedAt: now,
    };
    store.posts[idx] = nextPost;
    await writeLocalStore(store);
    const commentCount = store.comments.filter((c) => c.postId === postId && !c.isModerated).length;
    return {
      ...nextPost,
      commentCount,
      readMinutes: estimateReadMinutes(nextPost.content),
    };
  });
}

export async function moderatePost(
  postId: string,
  updates: { moderationStatus: ModerationStatus; status?: PostStatus; moderationNote: string },
): Promise<BlogPostWithMeta | null> {
  const now = new Date().toISOString();

  if (dbMode === 'mongodb') {
    const existing = await BlogPostModel.findOne({ postId }).lean();
    if (!existing) return null;
    const nextStatus = updates.status ?? existing.status;
    const updated = await BlogPostModel.findOneAndUpdate(
      { postId },
      {
        $set: {
          moderationStatus: updates.moderationStatus,
          status: nextStatus,
          moderationNote: updates.moderationNote,
          updatedAt: now,
        },
      },
      { new: true },
    ).lean();
    if (!updated) return null;
    const commentCount = await BlogCommentModel.countDocuments({ postId, isModerated: false });
    const post = mapPostDoc(updated);
    return { ...post, commentCount, readMinutes: estimateReadMinutes(post.content) };
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const idx = store.posts.findIndex((p) => p.id === postId);
    if (idx === -1) return null;
    const nextPost: BlogPostRecord = {
      ...store.posts[idx],
      moderationStatus: updates.moderationStatus,
      status: updates.status ?? store.posts[idx].status,
      moderationNote: updates.moderationNote,
      updatedAt: now,
    };
    store.posts[idx] = nextPost;
    await writeLocalStore(store);
    const commentCount = store.comments.filter((c) => c.postId === postId && !c.isModerated).length;
    return { ...nextPost, commentCount, readMinutes: estimateReadMinutes(nextPost.content) };
  });
}

export async function deletePost(postId: string): Promise<boolean> {
  if (dbMode === 'mongodb') {
    const result = await BlogPostModel.deleteOne({ postId });
    if ((result.deletedCount ?? 0) > 0) {
      await BlogCommentModel.deleteMany({ postId });
      return true;
    }
    return false;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const prevLen = store.posts.length;
    store.posts = store.posts.filter((p) => p.id !== postId);
    if (store.posts.length === prevLen) {
      return false;
    }
    store.comments = store.comments.filter((c) => c.postId !== postId);
    await writeLocalStore(store);
    return true;
  });
}

// ==================== COMMENT QUERIES ====================

export async function listCommentsForPost(postId: string): Promise<CommentRecord[]> {
  if (dbMode === 'mongodb') {
    const docs = await BlogCommentModel.find({ postId }).sort({ createdAt: 1 }).lean();
    return docs.map(mapCommentDoc);
  }
  const store = await readLocalStore();
  return store.comments
    .filter((c) => c.postId === postId)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

export async function listCommentsReceivedByAuthor(
  authorId: string,
): Promise<Array<CommentRecord & { postTitle: string }>> {
  let posts: BlogPostRecord[];
  let comments: CommentRecord[];
  if (dbMode === 'mongodb') {
    const [pDocs, cDocs] = await Promise.all([
      BlogPostModel.find({ authorId }).lean(),
      BlogCommentModel.find({}).sort({ createdAt: -1 }).lean(),
    ]);
    posts = pDocs.map(mapPostDoc);
    comments = cDocs.map(mapCommentDoc);
  } else {
    const store = await readLocalStore();
    posts = store.posts.filter((p) => p.authorId === authorId);
    comments = [...store.comments].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }

  const titleById = new Map(posts.map((p) => [p.id, p.title]));
  return comments
    .filter((c) => titleById.has(c.postId) && !c.isModerated)
    .slice(0, 20)
    .map((c) => ({ ...c, postTitle: titleById.get(c.postId) || 'Untitled Post' }));
}

export async function findCommentById(commentId: string): Promise<CommentRecord | null> {
  if (dbMode === 'mongodb') {
    const doc = await BlogCommentModel.findOne({ commentId }).lean();
    return doc ? mapCommentDoc(doc) : null;
  }
  const store = await readLocalStore();
  return store.comments.find((c) => c.id === commentId) ?? null;
}

export async function createComment(input: {
  postId: string;
  user: PublicUser;
  content: string;
  parentCommentId: string | null;
}): Promise<CommentRecord> {
  const now = new Date().toISOString();
  const record: CommentRecord = {
    id: `cmt-${crypto.randomUUID().slice(0, 8)}`,
    postId: input.postId,
    userId: input.user.id,
    authorName: input.user.name,
    authorRole: input.user.role,
    parentCommentId: input.parentCommentId,
    content: input.content,
    isModerated: false,
    moderationNote: '',
    createdAt: now,
    updatedAt: now,
  };

  if (dbMode === 'mongodb') {
    await BlogCommentModel.create({
      commentId: record.id,
      postId: record.postId,
      userId: record.userId,
      authorName: record.authorName,
      authorRole: record.authorRole,
      parentCommentId: record.parentCommentId,
      content: record.content,
      isModerated: record.isModerated,
      moderationNote: record.moderationNote,
      createdAt: record.createdAt,
      updatedAt: record.updatedAt,
    });
    return record;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    store.comments.push(record);
    await writeLocalStore(store);
    return record;
  });
}

export async function updateCommentContent(
  commentId: string,
  content: string,
): Promise<CommentRecord | null> {
  const now = new Date().toISOString();

  if (dbMode === 'mongodb') {
    const updated = await BlogCommentModel.findOneAndUpdate(
      { commentId },
      { $set: { content, updatedAt: now } },
      { new: true },
    ).lean();
    return updated ? mapCommentDoc(updated) : null;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const idx = store.comments.findIndex((c) => c.id === commentId);
    if (idx === -1) return null;
    store.comments[idx] = {
      ...store.comments[idx],
      content,
      updatedAt: now,
    };
    await writeLocalStore(store);
    return store.comments[idx];
  });
}

export async function moderateComment(
  commentId: string,
  updates: { isModerated: boolean; moderationNote: string },
): Promise<CommentRecord | null> {
  const now = new Date().toISOString();

  if (dbMode === 'mongodb') {
    const updated = await BlogCommentModel.findOneAndUpdate(
      { commentId },
      {
        $set: {
          isModerated: updates.isModerated,
          moderationNote: updates.moderationNote,
          updatedAt: now,
        },
      },
      { new: true },
    ).lean();
    return updated ? mapCommentDoc(updated) : null;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const idx = store.comments.findIndex((c) => c.id === commentId);
    if (idx === -1) return null;
    store.comments[idx] = {
      ...store.comments[idx],
      isModerated: updates.isModerated,
      moderationNote: updates.moderationNote,
      updatedAt: now,
    };
    await writeLocalStore(store);
    return store.comments[idx];
  });
}

export async function deleteCommentAndReplies(commentId: string): Promise<boolean> {
  if (dbMode === 'mongodb') {
    const all = await BlogCommentModel.find({}).lean();
    const toDelete = new Set<string>([commentId]);
    let added = true;
    while (added) {
      added = false;
      for (const c of all) {
        if (c.parentCommentId && toDelete.has(c.parentCommentId) && !toDelete.has(c.commentId)) {
          toDelete.add(c.commentId);
          added = true;
        }
      }
    }
    const result = await BlogCommentModel.deleteMany({ commentId: { $in: Array.from(toDelete) } });
    return (result.deletedCount ?? 0) > 0;
  }

  return serializeWrite(async () => {
    const store = await readLocalStore();
    const exists = store.comments.some((c) => c.id === commentId);
    if (!exists) return false;
    const toDelete = new Set<string>([commentId]);
    let added = true;
    while (added) {
      added = false;
      for (const c of store.comments) {
        if (c.parentCommentId && toDelete.has(c.parentCommentId) && !toDelete.has(c.id)) {
          toDelete.add(c.id);
          added = true;
        }
      }
    }
    store.comments = store.comments.filter((c) => !toDelete.has(c.id));
    await writeLocalStore(store);
    return true;
  });
}

// ==================== ADMIN OVERVIEW QUERIES ====================

export async function getAdminOverview(): Promise<{
  users: Array<PublicUser & { publishedCount: number; draftCount: number; commentCount: number }>;
  posts: BlogPostWithMeta[];
  comments: Array<CommentRecord & { postTitle: string }>;
}> {
  let users: UserRecord[];
  let posts: BlogPostRecord[];
  let comments: CommentRecord[];

  if (dbMode === 'mongodb') {
    const [uDocs, pDocs, cDocs] = await Promise.all([
      BlogUserModel.find({}).lean(),
      BlogPostModel.find({}).lean(),
      BlogCommentModel.find({}).sort({ createdAt: -1 }).lean(),
    ]);
    users = uDocs.map(mapUserDoc);
    posts = pDocs.map(mapPostDoc);
    comments = cDocs.map(mapCommentDoc);
  } else {
    const store = await readLocalStore();
    users = [...store.users];
    posts = [...store.posts];
    comments = [...store.comments].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }

  const postTitleMap = new Map(posts.map((p) => [p.id, p.title]));
  const commentCountByPost = new Map<string, number>();
  for (const c of comments) {
    commentCountByPost.set(c.postId, (commentCountByPost.get(c.postId) ?? 0) + 1);
  }

  const enrichedUsers = users
    .filter((u) => !u.isSeedAuthor)
    .map((u) => {
      const userPosts = posts.filter((p) => p.authorId === u.id);
      const userComments = comments.filter((c) => c.userId === u.id);
      return {
        ...toPublicUser(u),
        publishedCount: userPosts.filter((p) => p.status === 'published').length,
        draftCount: userPosts.filter((p) => p.status === 'draft').length,
        commentCount: userComments.length,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const enrichedPosts = [...posts]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .map((p) => ({
      ...p,
      commentCount: commentCountByPost.get(p.id) ?? 0,
      readMinutes: estimateReadMinutes(p.content),
    }));

  const enrichedComments = comments.map((c) => ({
    ...c,
    postTitle: postTitleMap.get(c.postId) || 'Deleted Post',
  }));

  return {
    users: enrichedUsers,
    posts: enrichedPosts,
    comments: enrichedComments,
  };
}
