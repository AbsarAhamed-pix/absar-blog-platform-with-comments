import { Router } from 'express';
import {
  authenticateJwt,
  getAdminSetupStatus,
  getEnvAdminConfig,
  hashPassword,
  optionalJwt,
  requireAdmin,
  signJwtToken,
  verifyLoginCredentials,
  type AuthenticatedRequest,
} from './auth.ts';
import {
  createComment,
  createPost,
  createUser,
  deleteCommentAndReplies,
  deletePost,
  findCommentById,
  findPostById,
  findUserByEmail,
  getAdminOverview,
  getDatabaseMode,
  hasAnyAdminUser,
  listCommentsForPost,
  listCommentsReceivedByAuthor,
  listPosts,
  listPublishedAuthors,
  moderateComment,
  moderatePost,
  toPublicUser,
  updateCommentContent,
  updatePost,
  updateUserProfile,
} from './db.ts';
import {
  cleanText,
  validateCommentInput,
  validateCommentModerationInput,
  validateLoginInput,
  validatePostInput,
  validatePostModerationInput,
  validateProfileUpdateInput,
  validateRegisterInput,
} from './validation.ts';

export const apiRouter = Router();

apiRouter.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    database: getDatabaseMode(),
    timestamp: new Date().toISOString(),
  });
});

// ==================== AUTHENTICATION ====================

apiRouter.get('/auth/admin-status', async (_req, res, next) => {
  try {
    const status = await getAdminSetupStatus();
    res.json(status);
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/setup-admin', async (req, res, next) => {
  try {
    if (getEnvAdminConfig()) {
      res.status(400).json({ error: 'Admin account is already configured via environment variables.' });
      return;
    }
    const exists = await hasAnyAdminUser();
    if (exists) {
      res.status(409).json({ error: 'Platform admin has already been claimed. Please sign in.' });
      return;
    }
    const validation = validateRegisterInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }
    const existingEmail = await findUserByEmail(validation.data.email);
    if (existingEmail) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const passwordHash = await hashPassword(validation.data.password);
    const created = await createUser({
      name: validation.data.name,
      email: validation.data.email,
      passwordHash,
      role: 'admin',
      headline: validation.data.headline || 'Managing Editor',
    });
    const user = toPublicUser(created);
    const token = signJwtToken(user);

    res.status(201).json({ token, user, message: 'Platform Admin account created.' });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/register', async (req, res, next) => {
  try {
    const validation = validateRegisterInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const envAdmin = getEnvAdminConfig();
    if (envAdmin && validation.data.email === envAdmin.email) {
      res.status(409).json({ error: 'This email is reserved.' });
      return;
    }

    const existing = await findUserByEmail(validation.data.email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const passwordHash = await hashPassword(validation.data.password);
    const created = await createUser({
      name: validation.data.name,
      email: validation.data.email,
      passwordHash,
      role: 'user',
      headline: validation.data.headline,
    });

    const user = toPublicUser(created);
    const token = signJwtToken(user);
    res.status(201).json({ token, user, message: 'Account created successfully.' });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/login', async (req, res, next) => {
  try {
    const validation = validateLoginInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const user = await verifyLoginCredentials(validation.data.email, validation.data.password);
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = signJwtToken(user);
    res.json({ token, user, message: 'Signed in successfully.' });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/logout', authenticateJwt, (_req, res) => {
  res.json({ message: 'Signed out successfully.' });
});

// ==================== USER PROFILE & DASHBOARD STATS ====================

apiRouter.get('/users/me', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const recentComments = await listCommentsReceivedByAuthor(req.user.id);
    res.json({ user: req.user, recentComments });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/users/me', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (req.user.id === 'env-admin') {
      res.status(400).json({ error: 'Environment-configured admin profile cannot be edited here.' });
      return;
    }
    const validation = validateProfileUpdateInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const updated = await updateUserProfile(req.user.id, validation.data);
    if (!updated) {
      res.status(404).json({ error: 'User profile not found.' });
      return;
    }

    const user = toPublicUser(updated);
    res.json({ user, message: 'Profile updated successfully.' });
  } catch (err) {
    next(err);
  }
});

// ==================== BLOG POST ROUTES ====================

apiRouter.get('/posts/authors', async (_req, res, next) => {
  try {
    const authors = await listPublishedAuthors();
    res.json({ authors });
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/posts', optionalJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    const search = typeof req.query.search === 'string' ? cleanText(req.query.search, 120) : undefined;
    const category =
      typeof req.query.category === 'string' ? cleanText(req.query.category, 40) : undefined;
    const authorId =
      typeof req.query.author === 'string' ? cleanText(req.query.author, 80) : undefined;
    const tag = typeof req.query.tag === 'string' ? cleanText(req.query.tag, 40) : undefined;
    const sort = typeof req.query.sort === 'string' ? cleanText(req.query.sort, 20) : 'latest';
    const scope = typeof req.query.scope === 'string' ? req.query.scope : 'public';

    if (scope === 'mine') {
      if (!req.user) {
        res.status(401).json({ error: 'Sign in to view your drafts and authored posts.' });
        return;
      }
      const posts = await listPosts({
        search,
        category,
        tag,
        sort,
        includeDraftsForAuthorId: req.user.id,
      });
      res.json({ posts });
      return;
    }

    if (scope === 'all') {
      if (!req.user || req.user.role !== 'admin') {
        res.status(403).json({ error: 'Administrator privileges required to view all posts.' });
        return;
      }
      const posts = await listPosts({
        search,
        category,
        authorId,
        tag,
        sort,
        includeAllForAdmin: true,
      });
      res.json({ posts });
      return;
    }

    const posts = await listPosts({ search, category, authorId, tag, sort });
    res.json({ posts });
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/posts/:id', optionalJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    const id = cleanText(req.params.id, 80);
    const post = await findPostById(id);
    if (!post) {
      res.status(404).json({ error: 'Blog post not found.' });
      return;
    }

    const isOwnerOrAdmin =
      Boolean(req.user) && (req.user!.id === post.authorId || req.user!.role === 'admin');
    if ((post.status === 'draft' || post.moderationStatus === 'flagged') && !isOwnerOrAdmin) {
      res.status(403).json({ error: 'You do not have permission to view this post.' });
      return;
    }

    res.json({ post });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/posts', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const validation = validatePostInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const post = await createPost({
      ...validation.data,
      author: req.user,
    });

    res.status(201).json({
      post,
      message:
        post.status === 'published'
          ? 'Blog post published.'
          : 'Draft saved to your studio.',
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/posts/:id', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const id = cleanText(req.params.id, 80);
    const existing = await findPostById(id);
    if (!existing) {
      res.status(404).json({ error: 'Blog post not found.' });
      return;
    }
    if (existing.authorId !== req.user.id && req.user.role !== 'admin') {
      res.status(403).json({ error: 'Only the original author or an administrator can edit this post.' });
      return;
    }

    const validation = validatePostInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const updated = await updatePost(id, validation.data);
    res.json({
      post: updated,
      message:
        updated?.status === 'published' ? 'Post updated and published.' : 'Draft updated.',
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.delete('/posts/:id', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const id = cleanText(req.params.id, 80);
    const existing = await findPostById(id);
    if (!existing) {
      res.status(404).json({ error: 'Blog post not found.' });
      return;
    }
    if (existing.authorId !== req.user.id && req.user.role !== 'admin') {
      res.status(403).json({ error: 'Only the original author or an administrator can delete this post.' });
      return;
    }

    await deletePost(id);
    res.json({ id, message: 'Blog post deleted.' });
  } catch (err) {
    next(err);
  }
});

// ==================== COMMENT ROUTES ====================

apiRouter.get(
  '/posts/:postId/comments',
  optionalJwt,
  async (req: AuthenticatedRequest, res, next) => {
    try {
      const postId = cleanText(req.params.postId, 80);
      const post = await findPostById(postId);
      if (!post) {
        res.status(404).json({ error: 'Blog post not found.' });
        return;
      }

      const isOwnerOrAdmin =
        Boolean(req.user) && (req.user!.id === post.authorId || req.user!.role === 'admin');
      if ((post.status === 'draft' || post.moderationStatus === 'flagged') && !isOwnerOrAdmin) {
        res.status(403).json({ error: 'Access denied.' });
        return;
      }

      const comments = await listCommentsForPost(postId);
      const visibleComments =
        req.user?.role === 'admin' ? comments : comments.filter((c) => !c.isModerated);

      res.json({ comments: visibleComments });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.post(
  '/posts/:postId/comments',
  authenticateJwt,
  async (req: AuthenticatedRequest, res, next) => {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required.' });
        return;
      }
      const postId = cleanText(req.params.postId, 80);
      const post = await findPostById(postId);
      if (!post) {
        res.status(404).json({ error: 'Blog post not found.' });
        return;
      }
      if (post.status !== 'published' || post.moderationStatus === 'flagged') {
        res.status(400).json({ error: 'Comments can only be posted on published articles.' });
        return;
      }

      const validation = validateCommentInput(req.body);
      if (!validation.ok || !validation.data) {
        res.status(400).json({ error: validation.error });
        return;
      }

      if (validation.data.parentCommentId) {
        const parent = await findCommentById(validation.data.parentCommentId);
        if (!parent || parent.postId !== postId) {
          res.status(400).json({ error: 'Parent comment not found on this post.' });
          return;
        }
      }

      const comment = await createComment({
        postId,
        user: req.user,
        content: validation.data.content,
        parentCommentId: validation.data.parentCommentId,
      });

      res.status(201).json({ comment, message: 'Comment published.' });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.put('/comments/:id', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const id = cleanText(req.params.id, 80);
    const existing = await findCommentById(id);
    if (!existing) {
      res.status(404).json({ error: 'Comment not found.' });
      return;
    }
    if (existing.userId !== req.user.id && req.user.role !== 'admin') {
      res.status(403).json({ error: 'You can only edit your own comments.' });
      return;
    }

    const validation = validateCommentInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const updated = await updateCommentContent(id, validation.data.content);
    res.json({ comment: updated, message: 'Comment updated.' });
  } catch (err) {
    next(err);
  }
});

apiRouter.delete('/comments/:id', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const id = cleanText(req.params.id, 80);
    const existing = await findCommentById(id);
    if (!existing) {
      res.status(404).json({ error: 'Comment not found.' });
      return;
    }
    if (existing.userId !== req.user.id && req.user.role !== 'admin') {
      res.status(403).json({ error: 'You can only delete your own comments.' });
      return;
    }

    await deleteCommentAndReplies(id);
    res.json({ id, message: 'Comment deleted.' });
  } catch (err) {
    next(err);
  }
});

// ==================== ADMIN MODERATION ROUTES ====================

apiRouter.get(
  '/admin/overview',
  authenticateJwt,
  requireAdmin,
  async (_req, res, next) => {
    try {
      const overview = await getAdminOverview();
      res.json(overview);
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.patch(
  '/admin/posts/:id/moderate',
  authenticateJwt,
  requireAdmin,
  async (req, res, next) => {
    try {
      const id = cleanText(req.params.id, 80);
      const validation = validatePostModerationInput(req.body);
      if (!validation.ok || !validation.data) {
        res.status(400).json({ error: validation.error });
        return;
      }
      const updated = await moderatePost(id, validation.data);
      if (!updated) {
        res.status(404).json({ error: 'Blog post not found.' });
        return;
      }
      res.json({ post: updated, message: 'Post moderation updated.' });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.patch(
  '/admin/comments/:id/moderate',
  authenticateJwt,
  requireAdmin,
  async (req, res, next) => {
    try {
      const id = cleanText(req.params.id, 80);
      const validation = validateCommentModerationInput(req.body);
      if (!validation.ok || !validation.data) {
        res.status(400).json({ error: validation.error });
        return;
      }
      const updated = await moderateComment(id, validation.data);
      if (!updated) {
        res.status(404).json({ error: 'Comment not found.' });
        return;
      }
      res.json({ comment: updated, message: 'Comment moderation updated.' });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.use((_req, res) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});
