export type UserRole = 'user' | 'admin';

export type BlogCategory =
  | 'Engineering'
  | 'Architecture'
  | 'Design Systems'
  | 'Databases'
  | 'Career';

export type PostStatus = 'draft' | 'published';

export type ModerationStatus = 'approved' | 'flagged';

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  headline: string;
  bio: string;
  location: string;
  website: string;
  isSeedAuthor?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PublicUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  headline: string;
  bio: string;
  location: string;
  website: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlogPostRecord {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: BlogCategory;
  tags: string[];
  authorId: string;
  authorName: string;
  authorHeadline: string;
  status: PostStatus;
  moderationStatus: ModerationStatus;
  moderationNote: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface BlogPostWithMeta extends BlogPostRecord {
  commentCount: number;
  readMinutes: number;
}

export interface CommentRecord {
  id: string;
  postId: string;
  userId: string;
  authorName: string;
  authorRole: UserRole;
  parentCommentId: string | null;
  content: string;
  isModerated: boolean;
  moderationNote: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlogStoreSnapshot {
  users: UserRecord[];
  posts: BlogPostRecord[];
  comments: CommentRecord[];
}
