# Vellum Journal — Full-Stack Blog Platform with Comments

**Student Name:** Absar Ahamed  
**College:** Easwari Engineering College, Chennai  
**Department:** Computer Science and Engineering (2nd Year)  
**Internship:** Thiranex Internship — Task 4  
**Repository Name:** `absar-blog-platform-with-comments`

---

## Architecture & Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Vite
- **Backend:** Node.js, Express.js REST API (`server.ts`, `server/routes.ts`)
- **Database:** MongoDB with Mongoose (`Users`, `BlogPosts`, `Comments` collections) + automatic persistent JSON store (`server/data/blog-store.json`) when `MONGODB_URI` is not configured
- **Authentication & Security:** JWT (`jsonwebtoken`), password hashing (`bcryptjs`), role-based access control (`user` vs `admin`), strict ownership verification, input/URL sanitization, `helmet`, and allowlisted `cors`

---

## Core Features

1. **User Authentication & Profiles**
   - Registration, sign-in, sign-out, password hashing (`bcryptjs`), and JWT-protected routes.
   - Editable user profile (name, headline, location, website, bio).
   - One-time first-run Admin setup form (or `ADMIN_EMAIL` / `ADMIN_PASSWORD` environment variables).
2. **Blog Post Management (CRUD + Drafts)**
   - Create posts with title, excerpt, body content, cover image (studio presets or custom HTTPS URL), category, and tags.
   - Save as **Draft** or **Publish** immediately.
   - Edit or delete own posts (with confirmation modal). Admins can manage any post.
3. **Threaded Comment System & Moderation**
   - Add comments on published articles and reply inline to existing comments.
   - Edit or delete own comments (with confirmation modal).
   - Admin moderation to flag/hide inappropriate comments or restore/remove them.
4. **Search, Filtering & Sorting**
   - Search by title, excerpt, body keywords, or tags.
   - Filter by category or author; sort by **Latest** or **Oldest**.
5. **User Studio Dashboard & Admin Console**
   - **Writer Studio:** Total published posts, draft count, comments received, **My Blogs** management, and recent comments received.
   - **Admin Console:** Role-gated view of registered users, all blog posts (with flag/unpublish/delete actions), and platform-wide comment moderation.
6. **Responsive Editorial UI & Light/Dark Mode**
   - Desktop, laptop, tablet, and mobile layouts with Light & Dark themes.

---

## REST API Endpoints

| Group | Method & Path | Access | Description |
| :--- | :--- | :--- | :--- |
| Health | `GET /api/health` | Public | Server & database mode status |
| Auth | `POST /api/auth/register` | Public | Register a new writer/reader (`role: "user"`) |
| Auth | `POST /api/auth/login` | Public | Authenticate and receive JWT token |
| Auth | `POST /api/auth/logout` | Authenticated | End session acknowledgement |
| Auth | `GET /api/auth/admin-status` | Public | Check if platform Admin is claimed/configured |
| Auth | `POST /api/auth/setup-admin` | One-time Public | Claim first-run Admin account (locks after claim) |
| Users | `GET /api/users/me` | Authenticated | Fetch current user's profile |
| Users | `PUT /api/users/me` | Authenticated | Update profile (`name`, `headline`, `location`, `website`, `bio`) |
| Posts | `GET /api/posts` | Public / Scoped | List published posts (`search`, `category`, `author`, `sort`, `scope=mine\|all`) |
| Posts | `GET /api/posts/authors` | Public | List distinct authors with published posts |
| Posts | `GET /api/posts/:id` | Public / Owner | Read post (drafts visible only to author or admin) |
| Posts | `POST /api/posts` | Authenticated | Create draft or published blog post |
| Posts | `PUT /api/posts/:id` | Owner / Admin | Update blog post |
| Posts | `DELETE /api/posts/:id` | Owner / Admin | Delete post and its comments |
| Comments | `GET /api/posts/:postId/comments` | Public / Owner | Retrieve comments & threaded replies for a post |
| Comments | `POST /api/posts/:postId/comments` | Authenticated | Add a comment or reply (`parentCommentId`) |
| Comments | `PUT /api/comments/:id` | Owner / Admin | Edit comment content |
| Comments | `DELETE /api/comments/:id` | Owner / Admin | Delete comment and child replies |
| Admin | `GET /api/admin/overview` | Admin only | Registered users, all posts, and all comments |
| Admin | `PATCH /api/admin/posts/:id/moderate` | Admin only | Flag/approve or unpublish a blog post |
| Admin | `PATCH /api/admin/comments/:id/moderate` | Admin only | Flag/hide or restore a comment |

---

## Local Setup & Deployment

1. Install dependencies:
   ```bash
   npm install
   ```
2. Configure environment variables based on `.env.example` (`MONGODB_URI`, `JWT_SECRET`, optional `ADMIN_EMAIL` & `ADMIN_PASSWORD`).
3. Start development server:
   ```bash
   npm run dev
   ```
4. Build and start for production:
   ```bash
   npm run build
   npm start
   ```
