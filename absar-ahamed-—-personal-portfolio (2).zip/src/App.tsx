import { useCallback, useEffect, useState } from 'react';
import { AdminDashboardView } from './components/AdminDashboardView';
import { ArticleDetailView } from './components/ArticleDetailView';
import { AuthModal } from './components/AuthModal';
import { JournalFeedView } from './components/JournalFeedView';
import { Navbar, type ActivePage } from './components/Navbar';
import { PostEditorModal } from './components/PostEditorModal';
import { ProfileView } from './components/ProfileView';
import { UserDashboardView } from './components/UserDashboardView';
import { api } from './lib/api';
import type { BlogPost, PublicUser } from './types';

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<PublicUser | null>(null);

  const [activePage, setActivePage] = useState<ActivePage>('feed');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [authors, setAuthors] = useState<Array<{ id: string; name: string }>>([]);
  const [feedLoading, setFeedLoading] = useState(true);
  const [feedError, setFeedError] = useState('');

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [authorId, setAuthorId] = useState('all');
  const [tag, setTag] = useState('');
  const [sort, setSort] = useState<'latest' | 'oldest'>('latest');

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [studioRefreshKey, setStudioRefreshKey] = useState(0);

  const [toast, setToast] = useState<{ message: string; isError: boolean } | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const notify = useCallback((message: string, isError = false) => {
    setToast({ message, isError });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const loadFeed = useCallback(async () => {
    setFeedLoading(true);
    setFeedError('');
    try {
      const [postsRes, authorsRes] = await Promise.all([
        api.listPosts({ search, category, author: authorId, tag, sort }, token),
        api.listAuthors(),
      ]);
      setPosts(postsRes.posts);
      setAuthors(authorsRes.authors);
    } catch (err) {
      setFeedError(err instanceof Error ? err.message : 'Unable to load blog posts.');
    } finally {
      setFeedLoading(false);
    }
  }, [search, category, authorId, tag, sort, token]);

  useEffect(() => {
    void loadFeed();
  }, [loadFeed]);

  const handleOpenPost = (postId: string) => {
    setSelectedPostId(postId);
    setActivePage('article');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAuthenticated = (nextToken: string, nextUser: PublicUser, notice: string) => {
    setToken(nextToken);
    setUser(nextUser);
    setAuthModalOpen(false);
    notify(notice);
  };

  const handleLogout = async () => {
    if (token) {
      try {
        await api.logout(token);
      } catch {
        // Proceed with clearing client state
      }
    }
    setToken(null);
    setUser(null);
    setActivePage('feed');
    notify('Signed out.');
  };

  const handlePostSaved = (saved: BlogPost, notice: string) => {
    setEditorOpen(false);
    setEditingPost(null);
    setStudioRefreshKey((k) => k + 1);
    void loadFeed();
    if (saved.status === 'published') {
      setSelectedPostId(saved.id);
      setActivePage('article');
    } else {
      setActivePage('dashboard');
    }
    notify(notice);
  };

  const handlePostDeleted = () => {
    setSelectedPostId(null);
    setActivePage('feed');
    setStudioRefreshKey((k) => k + 1);
    void loadFeed();
  };

  const handleResetFilters = () => {
    setSearch('');
    setCategory('All');
    setAuthorId('all');
    setTag('');
    setSort('latest');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#1C1917] dark:bg-[#0E1013] dark:text-[#F4F1EA] transition-colors">
      <Navbar
        activePage={activePage}
        user={user}
        theme={theme}
        onToggleTheme={() => setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))}
        onNavigate={(page) => {
          if (page === 'admin' && user?.role !== 'admin') {
            notify('Administrator privileges required.', true);
            return;
          }
          setActivePage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenNewPost={() => {
          setEditingPost(null);
          setEditorOpen(true);
        }}
      />

      <div className="flex-1">
        {activePage === 'feed' && (
          <JournalFeedView
            posts={posts}
            authors={authors}
            loading={feedLoading}
            error={feedError}
            search={search}
            category={category}
            authorId={authorId}
            tag={tag}
            sort={sort}
            onSearchChange={setSearch}
            onCategoryChange={setCategory}
            onAuthorChange={setAuthorId}
            onTagChange={(nextTag) => {
              setTag(nextTag);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSortChange={setSort}
            onOpenPost={handleOpenPost}
            onResetFilters={handleResetFilters}
          />
        )}

        {activePage === 'article' && selectedPostId && (
          <ArticleDetailView
            postId={selectedPostId}
            token={token}
            user={user}
            onBack={() => setActivePage('feed')}
            onEditPost={(post) => {
              setEditingPost(post);
              setEditorOpen(true);
            }}
            onPostDeleted={handlePostDeleted}
            onOpenAuth={() => setAuthModalOpen(true)}
            onNotify={notify}
          />
        )}

        {activePage === 'dashboard' && token && user && (
          <UserDashboardView
            token={token}
            user={user}
            refreshKey={studioRefreshKey}
            onNewPost={() => {
              setEditingPost(null);
              setEditorOpen(true);
            }}
            onEditPost={(post) => {
              setEditingPost(post);
              setEditorOpen(true);
            }}
            onOpenPost={handleOpenPost}
            onNotify={notify}
          />
        )}

        {activePage === 'profile' && token && user && (
          <ProfileView
            token={token}
            user={user}
            onUserUpdated={(updated) => {
              setUser(updated);
              void loadFeed();
            }}
            onLogout={() => void handleLogout()}
            onNotify={notify}
          />
        )}

        {activePage === 'admin' && token && user?.role === 'admin' && (
          <AdminDashboardView
            token={token}
            onOpenPost={handleOpenPost}
            onNotify={notify}
          />
        )}
      </div>

      <footer className="mt-16 border-t border-stone-200 dark:border-stone-800 py-8 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 dark:text-stone-400">
          <p className="font-serif text-sm text-stone-700 dark:text-stone-300">
            Vellum Journal · Built by Absar Ahamed, Easwari Engineering College
          </p>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => {
                setActivePage('feed');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              Essays
            </button>
            <button
              type="button"
              onClick={() => (user ? setActivePage('dashboard') : setAuthModalOpen(true))}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              Writer Studio
            </button>
            <button
              type="button"
              onClick={() => setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              {theme === 'dark' ? 'Light Theme' : 'Dark Theme'}
            </button>
          </div>
        </div>
      </footer>

      <AuthModal
        open={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthenticated={handleAuthenticated}
      />

      <PostEditorModal
        open={editorOpen}
        token={token}
        editingPost={editingPost}
        onClose={() => {
          setEditorOpen(false);
          setEditingPost(null);
        }}
        onSaved={handlePostSaved}
      />

      {toast && (
        <div
          role="status"
          aria-live="polite"
          className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl text-sm font-medium shadow-lg border ${
            toast.isError
              ? 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
              : 'bg-stone-900 dark:bg-stone-100 border-stone-800 dark:border-stone-200 text-white dark:text-stone-900'
          }`}
        >
          {toast.message}
        </div>
      )}
    </div>
  );
}
