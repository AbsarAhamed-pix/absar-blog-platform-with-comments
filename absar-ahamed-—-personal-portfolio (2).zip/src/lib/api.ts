import type {
  AdminOverviewData,
  BlogCategory,
  BlogComment,
  BlogPost,
  ModerationStatus,
  PostStatus,
  PublicUser,
  RecentReceivedComment,
} from '../types';

async function request<T>(
  path: string,
  options: RequestInit = {},
  token?: string | null,
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(path, { ...options, headers });
  const text = await res.text();
  let data: Record<string, unknown> = {};
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    data = { error: 'Unexpected server response.' };
  }

  if (!res.ok) {
    const message =
      typeof data.error === 'string' && data.error
        ? data.error
        : `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data as T;
}

export const api = {
  getAdminStatus() {
    return request<{ configured: boolean; source: 'env' | 'claimed' | 'unclaimed' }>(
      '/api/auth/admin-status',
    );
  },

  setupAdmin(payload: { name: string; email: string; password: string; headline?: string }) {
    return request<{ token: string; user: PublicUser; message: string }>(
      '/api/auth/setup-admin',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
    );
  },

  register(payload: { name: string; email: string; password: string; headline?: string }) {
    return request<{ token: string; user: PublicUser; message: string }>(
      '/api/auth/register',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
    );
  },

  login(payload: { email: string; password: string }) {
    return request<{ token: string; user: PublicUser; message: string }>(
      '/api/auth/login',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
    );
  },

  logout(token: string) {
    return request<{ message: string }>('/api/auth/logout', { method: 'POST' }, token);
  },

  getMe(token: string) {
    return request<{ user: PublicUser; recentComments: RecentReceivedComment[] }>(
      '/api/users/me',
      {},
      token,
    );
  },

  updateProfile(
    payload: { name: string; headline: string; bio: string; location: string; website: string },
    token: string,
  ) {
    return request<{ user: PublicUser; message: string }>(
      '/api/users/me',
      {
        method: 'PUT',
        body: JSON.stringify(payload),
      },
      token,
    );
  },

  listAuthors() {
    return request<{ authors: Array<{ id: string; name: string }> }>('/api/posts/authors');
  },

  listPosts(
    params: {
      search?: string;
      category?: string;
      author?: string;
      tag?: string;
      sort?: 'latest' | 'oldest';
      scope?: 'public' | 'mine' | 'all';
    } = {},
    token?: string | null,
  ) {
    const qs = new URLSearchParams();
    if (params.search) qs.set('search', params.search);
    if (params.category && params.category !== 'All') qs.set('category', params.category);
    if (params.author && params.author !== 'all') qs.set('author', params.author);
    if (params.tag) qs.set('tag', params.tag);
    if (params.sort) qs.set('sort', params.sort);
    if (params.scope) qs.set('scope', params.scope);
    const query = qs.toString();
    return request<{ posts: BlogPost[] }>(`/api/posts${query ? `?${query}` : ''}`, {}, token);
  },

  getPost(id: string, token?: string | null) {
    return request<{ post: BlogPost }>(`/api/posts/${encodeURIComponent(id)}`, {}, token);
  },

  createPost(
    payload: {
      title: string;
      excerpt: string;
      content: string;
      coverImage: string;
      category: BlogCategory;
      tags: string[];
      status: PostStatus;
    },
    token: string,
  ) {
    return request<{ post: BlogPost; message: string }>(
      '/api/posts',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
      token,
    );
  },

  updatePost(
    id: string,
    payload: {
      title: string;
      excerpt: string;
      content: string;
      coverImage: string;
      category: BlogCategory;
      tags: string[];
      status: PostStatus;
    },
    token: string,
  ) {
    return request<{ post: BlogPost; message: string }>(
      `/api/posts/${encodeURIComponent(id)}`,
      {
        method: 'PUT',
        body: JSON.stringify(payload),
      },
      token,
    );
  },

  deletePost(id: string, token: string) {
    return request<{ id: string; message: string }>(
      `/api/posts/${encodeURIComponent(id)}`,
      { method: 'DELETE' },
      token,
    );
  },

  listComments(postId: string, token?: string | null) {
    return request<{ comments: BlogComment[] }>(
      `/api/posts/${encodeURIComponent(postId)}/comments`,
      {},
      token,
    );
  },

  createComment(
    postId: string,
    payload: { content: string; parentCommentId?: string | null },
    token: string,
  ) {
    return request<{ comment: BlogComment; message: string }>(
      `/api/posts/${encodeURIComponent(postId)}/comments`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      },
      token,
    );
  },

  updateComment(commentId: string, content: string, token: string) {
    return request<{ comment: BlogComment; message: string }>(
      `/api/comments/${encodeURIComponent(commentId)}`,
      {
        method: 'PUT',
        body: JSON.stringify({ content }),
      },
      token,
    );
  },

  deleteComment(commentId: string, token: string) {
    return request<{ id: string; message: string }>(
      `/api/comments/${encodeURIComponent(commentId)}`,
      { method: 'DELETE' },
      token,
    );
  },

  getAdminOverview(token: string) {
    return request<AdminOverviewData>('/api/admin/overview', {}, token);
  },

  moderatePost(
    postId: string,
    payload: { moderationStatus: ModerationStatus; status?: PostStatus; moderationNote: string },
    token: string,
  ) {
    return request<{ post: BlogPost; message: string }>(
      `/api/admin/posts/${encodeURIComponent(postId)}/moderate`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      },
      token,
    );
  },

  moderateComment(
    commentId: string,
    payload: { isModerated: boolean; moderationNote: string },
    token: string,
  ) {
    return request<{ comment: BlogComment; message: string }>(
      `/api/admin/comments/${encodeURIComponent(commentId)}/moderate`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      },
      token,
    );
  },
};
