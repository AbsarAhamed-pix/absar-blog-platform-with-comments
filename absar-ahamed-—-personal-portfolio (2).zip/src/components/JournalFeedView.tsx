import { ArrowRight, Search, SlidersHorizontal, X } from 'lucide-react';
import { BLOG_CATEGORIES, formatEditorialDate, type BlogPost } from '../types';
import { CoverImage } from './CoverImage';

interface JournalFeedViewProps {
  posts: BlogPost[];
  authors: Array<{ id: string; name: string }>;
  loading: boolean;
  error: string;
  search: string;
  category: string;
  authorId: string;
  tag: string;
  sort: 'latest' | 'oldest';
  onSearchChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onAuthorChange: (value: string) => void;
  onTagChange: (value: string) => void;
  onSortChange: (value: 'latest' | 'oldest') => void;
  onOpenPost: (postId: string) => void;
  onResetFilters: () => void;
}

export function JournalFeedView({
  posts,
  authors,
  loading,
  error,
  search,
  category,
  authorId,
  tag,
  sort,
  onSearchChange,
  onCategoryChange,
  onAuthorChange,
  onTagChange,
  onSortChange,
  onOpenPost,
  onResetFilters,
}: JournalFeedViewProps) {
  const hasActiveFilter =
    Boolean(search.trim()) ||
    category !== 'All' ||
    authorId !== 'all' ||
    Boolean(tag) ||
    sort !== 'latest';

  const leadPost = !hasActiveFilter && posts.length > 0 ? posts[0] : null;
  const gridPosts = leadPost ? posts.slice(1) : posts;

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10 sm:py-12">
      {/* Editorial Masthead */}
      <section className="pb-8 border-b border-stone-200 dark:border-stone-800">
        <p className="text-xs font-mono tracking-widest uppercase text-stone-500 dark:text-stone-400">
          Engineering · Architecture · Craft Essays
        </p>
        <div className="mt-3 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <h1 className="font-serif text-4xl sm:text-5xl font-medium tracking-tight text-stone-900 dark:text-stone-100 text-balance max-w-2xl">
            Long-form notes on software systems and thoughtful design.
          </h1>
          <p className="text-sm sm:text-base text-stone-600 dark:text-stone-400 max-w-md leading-relaxed">
            An independent publication for builders to draft essays, publish architectural guides,
            and engage in structured peer discussion.
          </p>
        </div>
      </section>

      {/* Search, Category, Author & Sort Bar */}
      <section className="py-6 border-b border-stone-200 dark:border-stone-800 space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Search Input */}
          <div className="relative flex-1 max-w-xl">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search essays by title, keyword, tag, or author..."
              aria-label="Search blog posts"
              className="w-full pl-10 pr-4 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          {/* Author & Sort Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-stone-400 hidden sm:block" />
              <select
                value={authorId}
                onChange={(e) => onAuthorChange(e.target.value)}
                aria-label="Filter by author"
                className="px-3 py-2 text-sm rounded-lg border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] text-stone-800 dark:text-stone-200 focus:outline-2 focus:outline-[#1E3A8A]"
              >
                <option value="all">All Authors</option>
                {authors.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>

            <select
              value={sort}
              onChange={(e) => onSortChange(e.target.value === 'oldest' ? 'oldest' : 'latest')}
              aria-label="Sort articles"
              className="px-3 py-2 text-sm rounded-lg border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] text-stone-800 dark:text-stone-200 focus:outline-2 focus:outline-[#1E3A8A]"
            >
              <option value="latest">Latest First</option>
              <option value="oldest">Oldest First</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div
            className="flex items-center gap-1 overflow-x-auto pb-1"
            role="tablist"
            aria-label="Filter by category"
          >
            {BLOG_CATEGORIES.map((cat) => {
              const active = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => onCategoryChange(cat)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200/60 dark:hover:bg-stone-800'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {(tag || hasActiveFilter) && (
            <div className="flex items-center gap-3 text-xs text-stone-500 dark:text-stone-400">
              {tag && (
                <span>
                  Tag: <strong className="text-stone-800 dark:text-stone-200">#{tag}</strong>
                </span>
              )}
              <button
                type="button"
                onClick={onResetFilters}
                className="inline-flex items-center gap-1 text-[#1E3A8A] dark:text-blue-400 hover:underline whitespace-nowrap"
              >
                <X className="w-3.5 h-3.5" />
                Reset filters
              </button>
            </div>
          )}
        </div>
      </section>

      {error && (
        <div className="mt-8 p-4 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-sm text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map((idx) => (
            <div
              key={idx}
              className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] overflow-hidden animate-pulse"
            >
              <div className="aspect-[4/3] bg-stone-200 dark:bg-stone-800" />
              <div className="p-5 space-y-3">
                <div className="h-3 w-2/5 bg-stone-200 dark:bg-stone-800 rounded" />
                <div className="h-6 w-4/5 bg-stone-200 dark:bg-stone-800 rounded" />
                <div className="h-4 w-full bg-stone-200 dark:bg-stone-800 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="mt-12 py-16 px-6 text-center rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
          <h2 className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100">
            No matching essays found
          </h2>
          <p className="mt-2 text-sm text-stone-500 dark:text-stone-400 max-w-md mx-auto">
            Try clearing your search query or switching to a broader category or author filter.
          </p>
          {hasActiveFilter && (
            <button
              type="button"
              onClick={onResetFilters}
              className="mt-5 px-4 py-2 text-sm font-medium rounded-lg bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900"
            >
              View all published posts
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Tier 1: Lead Featured Story */}
          {leadPost && (
            <article
              onClick={() => onOpenPost(leadPost.id)}
              className="mt-10 pb-10 border-b border-stone-200 dark:border-stone-800 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch cursor-pointer group"
            >
              <div className="lg:col-span-7 overflow-hidden rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-100 dark:bg-stone-900 aspect-[16/9] lg:aspect-auto lg:min-h-[360px]">
                <CoverImage
                  src={leadPost.coverImage}
                  alt={leadPost.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                />
              </div>

              <div className="lg:col-span-5 flex flex-col justify-between py-1">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                    <span className="font-medium text-[#1E3A8A] dark:text-blue-400">
                      {leadPost.category}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{formatEditorialDate(leadPost.publishedAt || leadPost.createdAt)}</span>
                    <span aria-hidden="true">·</span>
                    <span>{leadPost.readMinutes} min read</span>
                    <span aria-hidden="true">·</span>
                    <span>{leadPost.commentCount} comments</span>
                  </div>

                  <h2 className="mt-3 font-serif text-3xl sm:text-4xl font-medium tracking-tight text-stone-900 dark:text-stone-100 group-hover:text-[#1E3A8A] dark:group-hover:text-blue-400 transition-colors text-balance">
                    {leadPost.title}
                  </h2>

                  <p className="mt-4 text-base leading-relaxed text-stone-600 dark:text-stone-300">
                    {leadPost.excerpt}
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-stone-900 dark:text-stone-100 truncate">
                      {leadPost.authorName}
                    </p>
                    <p className="text-xs text-stone-500 dark:text-stone-400 truncate">
                      {leadPost.authorHeadline || 'Contributor'}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[#1E3A8A] dark:text-blue-400 whitespace-nowrap shrink-0">
                    Read Essay
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </span>
                </div>
              </div>
            </article>
          )}

          {/* Tier 2: Secondary Archive Grid */}
          {gridPosts.length > 0 && (
            <section className="mt-10">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100">
                  {hasActiveFilter ? 'Matching Essays' : 'Recent Publications'}
                </h2>
                <span className="text-xs font-mono text-stone-500 dark:text-stone-400 tabular-nums">
                  {posts.length} {posts.length === 1 ? 'article' : 'articles'}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {gridPosts.map((post) => (
                  <article
                    key={post.id}
                    className="flex flex-col rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] overflow-hidden hover:border-stone-300 dark:hover:border-stone-700 transition-colors"
                  >
                    <button
                      type="button"
                      onClick={() => onOpenPost(post.id)}
                      className="aspect-[4/3] w-full overflow-hidden bg-stone-100 dark:bg-stone-900 text-left group"
                    >
                      <CoverImage
                        src={post.coverImage}
                        alt={post.title}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                    </button>

                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                          <span className="font-medium text-[#1E3A8A] dark:text-blue-400">
                            {post.category}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{formatEditorialDate(post.publishedAt || post.createdAt)}</span>
                          <span aria-hidden="true">·</span>
                          <span>{post.readMinutes} min</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => onOpenPost(post.id)}
                          className="mt-2.5 text-left block w-full"
                        >
                          <h3 className="font-serif text-xl font-medium leading-snug text-stone-900 dark:text-stone-100 hover:text-[#1E3A8A] dark:hover:text-blue-400 transition-colors">
                            {post.title}
                          </h3>
                        </button>

                        <p className="mt-2.5 text-sm leading-relaxed text-stone-600 dark:text-stone-400 line-clamp-3">
                          {post.excerpt}
                        </p>
                      </div>

                      <div className="mt-5 pt-4 border-t border-stone-100 dark:border-stone-800 space-y-2.5">
                        {post.tags.length > 0 && (
                          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-stone-500 dark:text-stone-400">
                            {post.tags.slice(0, 3).map((t) => (
                              <button
                                key={t}
                                type="button"
                                onClick={() => onTagChange(t)}
                                className="hover:text-[#1E3A8A] dark:hover:text-blue-400 transition-colors"
                              >
                                #{t}
                              </button>
                            ))}
                          </div>
                        )}
                        <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                          <span className="font-medium text-stone-800 dark:text-stone-200 truncate">
                            {post.authorName}
                          </span>
                          <span className="shrink-0">{post.commentCount} comments</span>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </main>
  );
}
