import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { api } from '../lib/api';
import {
  BLOG_CATEGORIES,
  STUDIO_COVER_PRESETS,
  type BlogCategory,
  type BlogPost,
  type PostStatus,
} from '../types';
import { CoverImage } from './CoverImage';

interface PostEditorModalProps {
  open: boolean;
  token: string | null;
  editingPost: BlogPost | null;
  onClose: () => void;
  onSaved: (post: BlogPost, notice: string) => void;
}

const EDITABLE_CATEGORIES = BLOG_CATEGORIES.filter((c) => c !== 'All') as BlogCategory[];

export function PostEditorModal({
  open,
  token,
  editingPost,
  onClose,
  onSaved,
}: PostEditorModalProps) {
  const [title, setTitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [category, setCategory] = useState<BlogCategory>('Engineering');
  const [tagsInput, setTagsInput] = useState('');
  const [coverImage, setCoverImage] = useState(STUDIO_COVER_PRESETS[0].url);
  const [content, setContent] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setError('');
    if (editingPost) {
      setTitle(editingPost.title);
      setExcerpt(editingPost.excerpt);
      setCategory(editingPost.category);
      setTagsInput(editingPost.tags.join(', '));
      setCoverImage(editingPost.coverImage || STUDIO_COVER_PRESETS[0].url);
      setContent(editingPost.content);
    } else {
      setTitle('');
      setExcerpt('');
      setCategory('Engineering');
      setTagsInput('');
      setCoverImage(STUDIO_COVER_PRESETS[0].url);
      setContent('');
    }
  }, [open, editingPost]);

  if (!open) return null;

  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;
  const estMinutes = Math.max(1, Math.ceil(wordCount / 180));

  const submitWithStatus = async (status: PostStatus) => {
    if (!token) {
      setError('Please sign in to publish or save drafts.');
      return;
    }
    setError('');
    setBusy(true);
    try {
      const tags = tagsInput
        .split(',')
        .map((t) => t.trim().toLowerCase().replace(/^#+/, ''))
        .filter(Boolean);

      const payload = {
        title,
        excerpt,
        content,
        coverImage,
        category,
        tags,
        status,
      };

      const res = editingPost
        ? await api.updatePost(editingPost.id, payload, token)
        : await api.createPost(payload, token);

      onSaved(res.post, res.message);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save blog post.');
    } finally {
      setBusy(false);
    }
  };

  const handlePublishSubmit = (e: FormEvent) => {
    e.preventDefault();
    void submitWithStatus('published');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="post-editor-title"
    >
      <div className="w-full max-w-3xl my-8 rounded-xl bg-white dark:bg-[#16191E] border border-stone-200 dark:border-stone-800 shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between gap-4">
          <div>
            <h2
              id="post-editor-title"
              className="font-serif text-xl font-semibold text-stone-900 dark:text-stone-100"
            >
              {editingPost ? 'Edit Essay' : 'Compose New Essay'}
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 tabular-nums">
              {wordCount} words · {estMinutes} min read estimate
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close editor"
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handlePublishSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Article Title
            </label>
            <input
              type="text"
              required
              minLength={4}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="A clear, descriptive headline..."
              className="w-full px-3.5 py-2.5 font-serif text-lg rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as BlogCategory)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
              >
                {EDITABLE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
                Tags (comma-separated)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="nodejs, mongodb, architecture"
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
              />
            </div>
          </div>

          {/* Cover Image Selector + Custom URL + Preview */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
            <div className="md:col-span-7 space-y-2.5">
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Cover Artwork
              </label>
              <div className="flex flex-wrap gap-1.5">
                {STUDIO_COVER_PRESETS.map((preset) => (
                  <button
                    key={preset.url}
                    type="button"
                    onClick={() => setCoverImage(preset.url)}
                    className={`px-2.5 py-1 text-xs rounded-md border transition-colors ${
                      coverImage === preset.url
                        ? 'border-[#1E3A8A] dark:border-blue-400 bg-blue-50 dark:bg-blue-950/40 text-[#1E3A8A] dark:text-blue-300 font-medium'
                        : 'border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="Or paste an https:// image URL"
                className="w-full px-3.5 py-2 text-xs rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
              />
            </div>
            <div className="md:col-span-5 aspect-[16/9] rounded-lg overflow-hidden border border-stone-200 dark:border-stone-700 bg-stone-100 dark:bg-stone-900">
              <CoverImage src={coverImage} alt={title || 'Cover preview'} />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Short Excerpt (optional — auto-generated if left blank)
            </label>
            <input
              type="text"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="A 1-2 sentence summary shown on the journal feed..."
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Article Body (separate paragraphs with a blank line)
            </label>
            <textarea
              rows={9}
              required
              minLength={20}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your essay here..."
              className="w-full px-3.5 py-3 text-sm leading-relaxed rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex flex-wrap items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={busy}
              className="px-4 py-2 text-sm font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => void submitWithStatus('draft')}
              className="px-4 py-2 text-sm font-medium rounded-lg border border-stone-300 dark:border-stone-600 text-stone-800 dark:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-60"
            >
              {busy ? 'Saving...' : 'Save as Draft'}
            </button>
            <button
              type="submit"
              disabled={busy}
              className="px-5 py-2 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white disabled:opacity-60"
            >
              {busy ? 'Publishing...' : editingPost?.status === 'published' ? 'Update Published' : 'Publish Essay'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
