import { useEffect, useState } from 'react';
import { Eye, EyeOff, Flag, ShieldCheck, Trash2, Users } from 'lucide-react';
import { api } from '../lib/api';
import {
  formatEditorialDate,
  type AdminOverviewData,
  type BlogPost,
  type RecentReceivedComment,
} from '../types';
import { ConfirmDialog } from './ConfirmDialog';

interface AdminDashboardViewProps {
  token: string;
  onOpenPost: (postId: string) => void;
  onNotify: (message: string, isError?: boolean) => void;
}

type AdminTab = 'posts' | 'comments' | 'users';

export function AdminDashboardView({
  token,
  onOpenPost,
  onNotify,
}: AdminDashboardViewProps) {
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<AdminTab>('posts');

  const [deletePostTarget, setDeletePostTarget] = useState<BlogPost | null>(null);
  const [deleteCommentTarget, setDeleteCommentTarget] =
    useState<RecentReceivedComment | null>(null);
  const [busy, setBusy] = useState(false);

  const loadOverview = async () => {
    setLoading(true);
    try {
      const overview = await api.getAdminOverview(token);
      setData(overview);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not load moderation overview.', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOverview();
  }, [token]);

  const handleTogglePostFlag = async (post: BlogPost) => {
    const nextFlag = post.moderationStatus === 'flagged' ? 'approved' : 'flagged';
    try {
      const res = await api.moderatePost(
        post.id,
        {
          moderationStatus: nextFlag,
          status: nextFlag === 'flagged' ? 'draft' : post.status,
          moderationNote:
            nextFlag === 'flagged' ? 'Flagged by editorial moderation' : '',
        },
        token,
      );
      setData((prev) =>
        prev
          ? {
              ...prev,
              posts: prev.posts.map((p) => (p.id === post.id ? res.post : p)),
            }
          : prev,
      );
      onNotify(
        nextFlag === 'flagged' ? 'Post flagged and unpublished.' : 'Post moderation cleared.',
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Moderation failed.', true);
    }
  };

  const handleToggleCommentModeration = async (comment: RecentReceivedComment) => {
    try {
      const nextHidden = !comment.isModerated;
      const res = await api.moderateComment(
        comment.id,
        {
          isModerated: nextHidden,
          moderationNote: nextHidden ? 'Hidden by moderator' : '',
        },
        token,
      );
      setData((prev) =>
        prev
          ? {
              ...prev,
              comments: prev.comments.map((c) =>
                c.id === comment.id ? { ...c, ...res.comment } : c,
              ),
            }
          : prev,
      );
      onNotify(nextHidden ? 'Comment hidden from public view.' : 'Comment restored.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not moderate comment.', true);
    }
  };

  const handleConfirmDeletePost = async () => {
    if (!deletePostTarget) return;
    setBusy(true);
    try {
      await api.deletePost(deletePostTarget.id, token);
      setData((prev) =>
        prev
          ? {
              ...prev,
              posts: prev.posts.filter((p) => p.id !== deletePostTarget.id),
              comments: prev.comments.filter((c) => c.postId !== deletePostTarget.id),
            }
          : prev,
      );
      setDeletePostTarget(null);
      onNotify('Post permanently deleted.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not delete post.', true);
    } finally {
      setBusy(false);
    }
  };

  const handleConfirmDeleteComment = async () => {
    if (!deleteCommentTarget) return;
    setBusy(true);
    try {
      await api.deleteComment(deleteCommentTarget.id, token);
      setData((prev) =>
        prev
          ? {
              ...prev,
              comments: prev.comments.filter((c) => c.id !== deleteCommentTarget.id),
            }
          : prev,
      );
      setDeleteCommentTarget(null);
      onNotify('Comment permanently removed.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not delete comment.', true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="pb-6 border-b border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-[#1E3A8A] dark:text-blue-400">
            Administrator Console
          </p>
          <h1 className="mt-2 font-serif text-3xl sm:text-4xl font-medium text-stone-900 dark:text-stone-100">
            Platform Moderation & Content
          </h1>
        </div>
        <div className="flex items-center gap-1 p-1 rounded-lg bg-stone-100 dark:bg-stone-800/80">
          <button
            type="button"
            onClick={() => setTab('posts')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'posts'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400'
            }`}
          >
            All Posts
          </button>
          <button
            type="button"
            onClick={() => setTab('comments')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'comments'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400'
            }`}
          >
            Comments
          </button>
          <button
            type="button"
            onClick={() => setTab('users')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'users'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400'
            }`}
          >
            Users
          </button>
        </div>
      </div>

      {loading || !data ? (
        <div className="p-10 text-center text-sm text-stone-500 dark:text-stone-400 border border-stone-200 dark:border-stone-800 rounded-xl bg-white dark:bg-[#16191E]">
          Loading platform moderation data...
        </div>
      ) : (
        <>
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
              <p className="text-xs text-stone-500 dark:text-stone-400">Total Posts</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
                {data.posts.length}
              </p>
            </div>
            <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
              <p className="text-xs text-stone-500 dark:text-stone-400">Flagged Posts</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-amber-700 dark:text-amber-400 tabular-nums">
                {data.posts.filter((p) => p.moderationStatus === 'flagged').length}
              </p>
            </div>
            <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
              <p className="text-xs text-stone-500 dark:text-stone-400">Total Comments</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
                {data.comments.length}
              </p>
            </div>
            <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
              <p className="text-xs text-stone-500 dark:text-stone-400">Registered Users</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
                {data.users.length}
              </p>
            </div>
          </section>

          {tab === 'posts' && (
            <section className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] divide-y divide-stone-200 dark:divide-stone-800">
              {data.posts.map((post) => (
                <div
                  key={post.id}
                  className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                      <span className="font-medium text-stone-800 dark:text-stone-200">
                        {post.authorName}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{post.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{post.status}</span>
                      {post.moderationStatus === 'flagged' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-red-700 dark:text-red-400 font-medium">
                            Flagged
                          </span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span>{post.commentCount} comments</span>
                    </div>
                    <h3 className="font-serif text-lg font-medium text-stone-900 dark:text-stone-100">
                      {post.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenPost(post.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Inspect
                    </button>
                    <button
                      type="button"
                      onClick={() => handleTogglePostFlag(post)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border ${
                        post.moderationStatus === 'flagged'
                          ? 'border-emerald-200 dark:border-emerald-900/60 text-emerald-700 dark:text-emerald-400'
                          : 'border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-400'
                      }`}
                    >
                      {post.moderationStatus === 'flagged' ? (
                        <>
                          <ShieldCheck className="w-3.5 h-3.5" />
                          Approve
                        </>
                      ) : (
                        <>
                          <Flag className="w-3.5 h-3.5" />
                          Flag
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeletePostTarget(post)}
                      aria-label={`Delete ${post.title}`}
                      className="p-2 rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </section>
          )}

          {tab === 'comments' && (
            <section className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] divide-y divide-stone-200 dark:divide-stone-800">
              {data.comments.length === 0 ? (
                <p className="p-8 text-center text-sm text-stone-500 dark:text-stone-400">
                  No comments found on the platform.
                </p>
              ) : (
                data.comments.map((cmt) => (
                  <div
                    key={cmt.id}
                    className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="min-w-0 space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                        <span className="font-medium text-stone-900 dark:text-stone-100">
                          {cmt.authorName}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{formatEditorialDate(cmt.createdAt)}</span>
                        <span aria-hidden="true">·</span>
                        <button
                          type="button"
                          onClick={() => onOpenPost(cmt.postId)}
                          className="text-[#1E3A8A] dark:text-blue-400 hover:underline truncate max-w-[260px]"
                        >
                          {cmt.postTitle}
                        </button>
                        {cmt.isModerated && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-700 dark:text-amber-400 font-medium">
                              Hidden
                            </span>
                          </>
                        )}
                      </div>
                      <p className="text-sm text-stone-700 dark:text-stone-300">{cmt.content}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleCommentModeration(cmt)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
                      >
                        {cmt.isModerated ? (
                          <>
                            <Eye className="w-3.5 h-3.5" />
                            Restore
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3.5 h-3.5" />
                            Hide
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteCommentTarget(cmt)}
                        aria-label="Delete comment"
                        className="p-2 rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </section>
          )}

          {tab === 'users' && (
            <section className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] overflow-x-auto">
              {data.users.length === 0 ? (
                <div className="p-10 text-center text-sm text-stone-500 dark:text-stone-400">
                  <Users className="w-6 h-6 mx-auto mb-2 opacity-60" />
                  No registered user accounts yet.
                </div>
              ) : (
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-stone-200 dark:border-stone-800 text-xs text-stone-500 dark:text-stone-400">
                      <th className="py-3.5 px-5 font-medium">User</th>
                      <th className="py-3.5 px-5 font-medium">Role</th>
                      <th className="py-3.5 px-5 font-medium text-right">Published</th>
                      <th className="py-3.5 px-5 font-medium text-right">Drafts</th>
                      <th className="py-3.5 px-5 font-medium text-right">Comments</th>
                      <th className="py-3.5 px-5 font-medium text-right">Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 dark:divide-stone-800">
                    {data.users.map((u) => (
                      <tr key={u.id}>
                        <td className="py-3.5 px-5">
                          <p className="font-medium text-stone-900 dark:text-stone-100">{u.name}</p>
                          <p className="text-xs text-stone-500 dark:text-stone-400">{u.email}</p>
                        </td>
                        <td className="py-3.5 px-5 capitalize text-xs font-medium text-stone-700 dark:text-stone-300">
                          {u.role}
                        </td>
                        <td className="py-3.5 px-5 text-right tabular-nums">{u.publishedCount}</td>
                        <td className="py-3.5 px-5 text-right tabular-nums">{u.draftCount}</td>
                        <td className="py-3.5 px-5 text-right tabular-nums">{u.commentCount}</td>
                        <td className="py-3.5 px-5 text-right text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                          {formatEditorialDate(u.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>
          )}
        </>
      )}

      <ConfirmDialog
        open={Boolean(deletePostTarget)}
        title="Remove Post"
        description={`Delete "${deletePostTarget?.title || ''}" and all of its associated comments?`}
        confirmLabel="Remove Post"
        busy={busy}
        onCancel={() => setDeletePostTarget(null)}
        onConfirm={handleConfirmDeletePost}
      />

      <ConfirmDialog
        open={Boolean(deleteCommentTarget)}
        title="Delete Comment"
        description="Permanently delete this comment and any direct replies?"
        confirmLabel="Delete Comment"
        busy={busy}
        onCancel={() => setDeleteCommentTarget(null)}
        onConfirm={handleConfirmDeleteComment}
      />
    </main>
  );
}
