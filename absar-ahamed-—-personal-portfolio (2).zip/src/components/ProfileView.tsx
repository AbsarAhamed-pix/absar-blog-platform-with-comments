import { useState, type FormEvent } from 'react';
import { LogOut, UserCheck } from 'lucide-react';
import { api } from '../lib/api';
import { formatEditorialDate, type PublicUser } from '../types';

interface ProfileViewProps {
  token: string;
  user: PublicUser;
  onUserUpdated: (user: PublicUser) => void;
  onLogout: () => void;
  onNotify: (message: string, isError?: boolean) => void;
}

export function ProfileView({
  token,
  user,
  onUserUpdated,
  onLogout,
  onNotify,
}: ProfileViewProps) {
  const [name, setName] = useState(user.name);
  const [headline, setHeadline] = useState(user.headline);
  const [location, setLocation] = useState(user.location);
  const [website, setWebsite] = useState(user.website);
  const [bio, setBio] = useState(user.bio);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.updateProfile(
        { name, headline, location, website, bio },
        token,
      );
      onUserUpdated(res.user);
      onNotify(res.message);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not update profile.', true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <main className="max-w-3xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-stone-200 dark:border-stone-800">
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-stone-500 dark:text-stone-400">
            Account & Author Profile
          </p>
          <h1 className="mt-2 font-serif text-3xl sm:text-4xl font-medium text-stone-900 dark:text-stone-100">
            {user.name}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
            <span>{user.email}</span>
            <span aria-hidden="true">·</span>
            <span className="capitalize font-medium text-[#1E3A8A] dark:text-blue-400">
              {user.role === 'admin' ? 'Administrator / Editor' : 'Contributor'}
            </span>
            <span aria-hidden="true">·</span>
            <span>Joined {formatEditorialDate(user.createdAt)}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onLogout}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 whitespace-nowrap shrink-0"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>

      <form
        onSubmit={handleSubmit}
        className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] p-6 sm:p-8 space-y-5"
      >
        <div className="flex items-center gap-2 text-sm font-medium text-stone-900 dark:text-stone-100">
          <UserCheck className="w-4 h-4 text-[#1E3A8A] dark:text-blue-400" />
          Public Author Attribution
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              required
              minLength={2}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Editorial Headline
            </label>
            <input
              type="text"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              placeholder="2nd Year CSE Student, Chennai"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Location
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Chennai, India"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Website / Portfolio URL
            </label>
            <input
              type="url"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder="https://example.com"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
            Short Bio
          </label>
          <textarea
            rows={4}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Share what topics you write about..."
            className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
          />
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            disabled={saving || user.id === 'env-admin'}
            className="px-5 py-2.5 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Profile Changes'}
          </button>
        </div>
      </form>
    </main>
  );
}
