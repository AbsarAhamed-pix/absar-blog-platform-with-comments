import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  ArrowLeft,
  Edit3,
  EyeOff,
  MessageSquare,
  Reply,
  ShieldAlert,
  Trash2,
} from 'lucide-react';
import { api } from '../lib/api';
import { formatEditorialDate, type BlogComment, type BlogPost, type PublicUser } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { CoverImage } from './CoverImage';

interface ArticleDetailViewProps {
  postId: string;
  token: string | null;
  user: PublicUser | null;
  onBack: () => void;
  onEditPost: (post: BlogPost) => void;
  onPostDeleted: (postId: string) => void;
  onOpenAuth: () => void;
  onNotify: (message: string, isError?: boolean) => void;
}

export function ArticleDetailView({
  postId,
  token,
  user,
  onBack,
  onEditPost,
  onPostDeleted,
  onOpenAuth,
  onNotify,
}: ArticleDetailViewProps) {
  const [post, setPost] = useState<BlogPost | null>(null);
  const [comments, setComments] = useState<BlogComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [readProgress, setReadProgress] = useState(0);

  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  const [replyingToId, setReplyingToId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editingCommentText, setEditingCommentText] = useState('');

  const [confirmDeletePost, setConfirmDeletePost] = useState(false);
  const [confirmDeleteCommentId, setConfirmDeleteCommentId] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight <= 0) {
        setReadProgress(100);
      } else {
        setReadProgress(Math.min(100, Math.max(0, Math.round((window.scrollY / docHeight) * 100))));
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError('');

    Promise.all([api.getPost(postId, token), api.listComments(postId, token)])
      .then(([postRes, cmtRes]) => {
        if (!active) return;
        setPost(postRes.post);
        setComments(cmtRes.comments);
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Unable to load article.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [postId, token]);

  const canModifyPost =
    Boolean(user && post) && (user!.id === post!.authorId || user!.role === 'admin');

  const topLevelComments = useMemo(
    () => comments.filter((c) => !c.parentCommentId),
    [comments],
  );

  const repliesByParent = useMemo(() => {
    const map = new Map<string, BlogComment[]>();
    for (const c of comments) {
      if (c.parentCommentId) {
        const list = map.get(c.parentCommentId) || [];
        list.push(c);
        map.set(c.parentCommentId, list);
      }
    }
    return map;
  }, [comments]);

  const handleAddComment = async (e: FormEvent) => {
    e.preventDefault();
    if (!token || !user) {
      onOpenAuth();
      return;
    }
    if (!newComment.trim()) return;
    setSubmittingComment(true);
    try {
      const res = await api.createComment(postId, { content: newComment.trim() }, token);
      setComments((prev) => [...prev, res.comment]);
      setNewComment('');
      onNotify(res.message);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not post comment.', true);
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleAddReply = async (e: FormEvent, parentId: string) => {
    e.preventDefault();
    if (!token || !user) {
      onOpenAuth();
      return;
    }
    if (!replyText.trim()) return;
    setSubmittingComment(true);
    try {
      const res = await api.createComment(
        postId,
        { content: replyText.trim(), parentCommentId: parentId },
        token,
      );
      setComments((prev) => [...prev, res.comment]);
      setReplyingToId(null);
      setReplyText('');
      onNotify('Reply posted.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not post reply.', true);
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleSaveCommentEdit = async (e: FormEvent, commentId: string) => {
    e.preventDefault();
    if (!token || !editingCommentText.trim()) return;
    try {
      const res = await api.updateComment(commentId, editingCommentText.trim(), token);
      setComments((prev) => prev.map((c) => (c.id === commentId ? res.comment : c)));
      setEditingCommentId(null);
      setEditingCommentText('');
      onNotify('Comment updated.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not update comment.', true);
    }
  };

  const handleToggleModerateComment = async (comment: BlogComment) => {
    if (!token || user?.role !== 'admin') return;
    try {
      const res = await api.moderateComment(
        comment.id,
        {
          isModerated: !comment.isModerated,
          moderationNote: !comment.isModerated ? 'Hidden by moderator' : '',
        },
        token,
      );
      setComments((prev) => prev.map((c) => (c.id === comment.id ? res.comment : c)));
      onNotify(res.message);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Moderation failed.', true);
    }
  };

  const handleConfirmDeletePost = async () => {
    if (!token || !post) return;
    setDeleteBusy(true);
    try {
      await api.deletePost(post.id, token);
      setConfirmDeletePost(false);
      onNotify('Blog post deleted.');
      onPostDeleted(post.id);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not delete post.', true);
    } finally {
      setDeleteBusy(false);
    }
  };

  const handleConfirmDeleteComment = async () => {
    if (!token || !confirmDeleteCommentId) return;
    setDeleteBusy(true);
    try {
      await api.deleteComment(confirmDeleteCommentId, token);
      const removedIds = new Set<string>([confirmDeleteCommentId]);
      let added = true;
      while (added) {
        added = false;
        for (const c of comments) {
          if (c.parentCommentId && removedIds.has(c.parentCommentId) && !removedIds.has(c.id)) {
            removedIds.add(c.id);
            added = true;
          }
        }
      }
      setComments((prev) => prev.filter((c) => !removedIds.has(c.id)));
      setConfirmDeleteCommentId(null);
      onNotify('Comment deleted.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not delete comment.', true);
    } finally {
      setDeleteBusy(false);
    }
  };

  const renderCommentNode = (comment: BlogComment, isReply = false) => {
    const canEdit = Boolean(user) && (user!.id === comment.userId || user!.role === 'admin');
    const replies = repliesByParent.get(comment.id) || [];

    return (
      <div
        key={comment.id}
        className={`${
          isReply
            ? 'mt-4 pl-4 sm:pl-6 border-l border-stone-200 dark:border-stone-800'
            : 'py-5 border-b border-stone-200 dark:border-stone-800 last:border-b-0'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400">
            <span className="font-semibold text-sm text-stone-900 dark:text-stone-100">
              {comment.authorName}
            </span>
            {comment.authorRole === 'admin' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-[#1E3A8A] dark:text-blue-400">Editor</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{formatEditorialDate(comment.createdAt)}</span>
            {comment.updatedAt !== comment.createdAt && (
              <>
                <span aria-hidden="true">·</span>
                <span>Edited</span>
              </>
            )}
            {comment.isModerated && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-amber-700 dark:text-amber-400 font-medium">
                  Hidden by moderator
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 text-xs">
            {!isReply && post?.status === 'published' && (
              <button
                type="button"
                onClick={() => {
                  if (!user) {
                    onOpenAuth();
                    return;
                  }
                  setReplyingToId(replyingToId === comment.id ? null : comment.id);
                  setReplyText('');
                }}
                className="inline-flex items-center gap-1 text-stone-500 dark:text-stone-400 hover:text-[#1E3A8A] dark:hover:text-blue-400 transition-colors"
              >
                <Reply className="w-3.5 h-3.5" />
                Reply
              </button>
            )}
            {canEdit && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setEditingCommentId(comment.id);
                    setEditingCommentText(comment.content);
                  }}
                  className="inline-flex items-center gap-1 text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteCommentId(comment.id)}
                  className="inline-flex items-center gap-1 text-stone-500 dark:text-stone-400 hover:text-red-700 dark:hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </button>
              </>
            )}
            {user?.role === 'admin' && (
              <button
                type="button"
                onClick={() => handleToggleModerateComment(comment)}
                className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 hover:underline"
              >
                <EyeOff className="w-3.5 h-3.5" />
                {comment.isModerated ? 'Restore' : 'Hide'}
              </button>
            )}
          </div>
        </div>

        {editingCommentId === comment.id ? (
          <form onSubmit={(e) => handleSaveCommentEdit(e, comment.id)} className="mt-3 space-y-2.5">
            <textarea
              rows={3}
              required
              minLength={2}
              value={editingCommentText}
              onChange={(e) => setEditingCommentText(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#1E3A8A] text-white hover:bg-[#172D6B]"
              >
                Save Changes
              </button>
              <button
                type="button"
                onClick={() => setEditingCommentId(null)}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <p className="mt-2.5 text-sm leading-relaxed text-stone-700 dark:text-stone-300 whitespace-pre-line">
            {comment.content}
          </p>
        )}

        {replyingToId === comment.id && (
          <form onSubmit={(e) => handleAddReply(e, comment.id)} className="mt-3 space-y-2.5">
            <textarea
              rows={2}
              required
              minLength={2}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder={`Reply to ${comment.authorName}...`}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={submittingComment}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#1E3A8A] text-white hover:bg-[#172D6B] disabled:opacity-60"
              >
                Post Reply
              </button>
              <button
                type="button"
                onClick={() => setReplyingToId(null)}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {replies.length > 0 && (
          <div className="mt-3 space-y-3">{replies.map((r) => renderCommentNode(r, true))}</div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-12 animate-pulse space-y-6">
        <div className="h-4 w-28 bg-stone-200 dark:bg-stone-800 rounded" />
        <div className="h-12 w-5/6 bg-stone-200 dark:bg-stone-800 rounded" />
        <div className="aspect-[16/9] bg-stone-200 dark:bg-stone-800 rounded-xl" />
      </main>
    );
  }

  if (error || !post) {
    return (
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-14 text-center">
        <p className="text-sm text-red-700 dark:text-red-400">{error || 'Post not found.'}</p>
        <button
          type="button"
          onClick={onBack}
          className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg border border-stone-200 dark:border-stone-800"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Journal
        </button>
      </main>
    );
  }

  const paragraphs = post.content.split(/\n{2,}/).filter((p) => p.trim().length > 0);

  return (
    <>
      {/* Subtle Reading Depth Bar */}
      <div className="fixed top-16 left-0 right-0 h-0.5 bg-transparent z-30 pointer-events-none">
        <div
          className="h-full bg-[#1E3A8A] dark:bg-blue-400 transition-[width] duration-150"
          style={{ width: `${readProgress}%` }}
        />
      </div>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-10 sm:py-12">
        <div className="flex items-center justify-between gap-4 mb-8">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-sm font-medium text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            All Essays
          </button>

          {canModifyPost && (
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => onEditPost(post)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                <Edit3 className="w-3.5 h-3.5" />
                Edit Post
              </button>
              <button
                type="button"
                onClick={() => setConfirmDeletePost(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete
              </button>
            </div>
          )}
        </div>

        {(post.status === 'draft' || post.moderationStatus === 'flagged') && (
          <div className="mb-6 p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/30 flex items-center gap-2.5 text-xs text-amber-900 dark:text-amber-200">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>
              {post.moderationStatus === 'flagged'
                ? `This post has been flagged by moderation${post.moderationNote ? `: ${post.moderationNote}` : '.'}`
                : 'Draft preview — only visible to you and platform editors until published.'}
            </span>
          </div>
        )}

        <article>
          <header className="max-w-3xl">
            <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
              <span className="font-medium text-[#1E3A8A] dark:text-blue-400">{post.category}</span>
              <span aria-hidden="true">·</span>
              <span>
                {post.status === 'published'
                  ? `Published ${formatEditorialDate(post.publishedAt || post.createdAt)}`
                  : 'Saved Draft'}
              </span>
              <span aria-hidden="true">·</span>
              <span>{post.readMinutes} min read</span>
              <span aria-hidden="true">·</span>
              <span>{comments.length} comments</span>
            </div>

            <h1 className="mt-4 font-serif text-3xl sm:text-5xl font-medium tracking-tight text-stone-900 dark:text-stone-100 leading-[1.12] text-balance">
              {post.title}
            </h1>

            <p className="mt-4 text-lg leading-relaxed text-stone-600 dark:text-stone-300">
              {post.excerpt}
            </p>

            <div className="mt-6 pt-5 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                  {post.authorName}
                </p>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {post.authorHeadline || 'Contributor'}
                </p>
              </div>
              {post.tags.length > 0 && (
                <div className="flex flex-wrap items-center justify-end gap-2 text-xs text-stone-500 dark:text-stone-400">
                  {post.tags.map((t) => (
                    <span key={t}>#{t}</span>
                  ))}
                </div>
              )}
            </div>
          </header>

          <figure className="mt-8">
            <div className="aspect-[16/9] w-full overflow-hidden rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-100 dark:bg-stone-900">
              <CoverImage src={post.coverImage} alt={post.title} />
            </div>
          </figure>

          {/* Editorial Reading Column (68ch measure) */}
          <div className="mt-10 max-w-2xl mx-auto space-y-6 text-base sm:text-[17px] leading-[1.78] text-stone-800 dark:text-stone-200">
            {paragraphs.map((para, idx) => (
              <p
                key={idx}
                className={
                  idx === 0
                    ? 'first-letter:text-5xl first-letter:font-serif first-letter:font-semibold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:leading-none text-stone-900 dark:text-stone-100'
                    : 'whitespace-pre-line'
                }
              >
                {para}
              </p>
            ))}
          </div>
        </article>

        {/* Discussion & Comments */}
        <section
          aria-labelledby="discussion-heading"
          className="mt-14 pt-10 border-t border-stone-200 dark:border-stone-800 max-w-2xl mx-auto"
        >
          <div className="flex items-center justify-between gap-4">
            <h2
              id="discussion-heading"
              className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100 flex items-center gap-2.5"
            >
              <MessageSquare className="w-5 h-5 text-[#1E3A8A] dark:text-blue-400" />
              Reader Discussion ({comments.length})
            </h2>
          </div>

          {post.status === 'published' && post.moderationStatus !== 'flagged' && (
            <div className="mt-6">
              {user ? (
                <form onSubmit={handleAddComment} className="space-y-3">
                  <textarea
                    rows={3}
                    required
                    minLength={2}
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={`Share your perspective as ${user.name}...`}
                    className="w-full px-4 py-3 text-sm rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-2 focus:outline-[#1E3A8A]"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={submittingComment}
                      className="px-4 py-2 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors disabled:opacity-60"
                    >
                      {submittingComment ? 'Posting...' : 'Post Comment'}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="p-4 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <p className="text-sm text-stone-600 dark:text-stone-300">
                    Sign in or register as a contributor to join the discussion.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenAuth}
                    className="px-4 py-2 text-sm font-medium rounded-lg bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 whitespace-nowrap shrink-0"
                  >
                    Sign In to Comment
                  </button>
                </div>
              )}
            </div>
          )}

          <div className="mt-6">
            {topLevelComments.length === 0 ? (
              <p className="py-8 text-sm text-center text-stone-500 dark:text-stone-400 border-t border-stone-200 dark:border-stone-800">
                No comments yet. Be the first reader to respond.
              </p>
            ) : (
              <div>{topLevelComments.map((comment) => renderCommentNode(comment, false))}</div>
            )}
          </div>
        </section>
      </main>

      <ConfirmDialog
        open={confirmDeletePost}
        title="Delete Blog Post"
        description={`Are you sure you want to permanently delete "${post.title}" and all of its reader comments?`}
        confirmLabel="Delete Post"
        busy={deleteBusy}
        onCancel={() => setConfirmDeletePost(false)}
        onConfirm={handleConfirmDeletePost}
      />

      <ConfirmDialog
        open={Boolean(confirmDeleteCommentId)}
        title="Delete Comment"
        description="Are you sure you want to permanently remove this comment and any direct replies?"
        confirmLabel="Delete Comment"
        busy={deleteBusy}
        onCancel={() => setConfirmDeleteCommentId(null)}
        onConfirm={handleConfirmDeleteComment}
      />
    </>
  );
}
