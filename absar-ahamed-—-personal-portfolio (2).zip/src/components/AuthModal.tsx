import { useEffect, useState, type FormEvent } from 'react';
import { ShieldCheck, X } from 'lucide-react';
import { api } from '../lib/api';
import type { PublicUser } from '../types';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onAuthenticated: (token: string, user: PublicUser, notice: string) => void;
}

type AuthTab = 'login' | 'register' | 'claim-admin';

export function AuthModal({ open, onClose, onAuthenticated }: AuthModalProps) {
  const [tab, setTab] = useState<AuthTab>('login');
  const [adminUnclaimed, setAdminUnclaimed] = useState(false);
  const [name, setName] = useState('');
  const [headline, setHeadline] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setError('');
    api
      .getAdminStatus()
      .then((res) => {
        setAdminUnclaimed(!res.configured && res.source === 'unclaimed');
      })
      .catch(() => setAdminUnclaimed(false));
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);

    try {
      if (tab === 'login') {
        const res = await api.login({ email, password });
        onAuthenticated(res.token, res.user, res.message);
      } else if (tab === 'register') {
        const res = await api.register({ name, email, password, headline });
        onAuthenticated(res.token, res.user, res.message);
      } else {
        const res = await api.setupAdmin({
          name,
          email,
          password,
          headline: headline || 'Managing Editor',
        });
        onAuthenticated(res.token, res.user, res.message);
      }
      setName('');
      setHeadline('');
      setEmail('');
      setPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-md rounded-xl bg-white dark:bg-[#16191E] border border-stone-200 dark:border-stone-800 p-6 sm:p-7 shadow-xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2
              id="auth-modal-title"
              className="font-serif text-2xl font-semibold text-stone-900 dark:text-stone-100"
            >
              {tab === 'login'
                ? 'Sign in to Vellum Journal'
                : tab === 'register'
                  ? 'Join as a Contributor'
                  : 'First-Run Admin Setup'}
            </h2>
            <p className="mt-1 text-sm text-stone-500 dark:text-stone-400">
              {tab === 'login'
                ? 'Publish essays, manage drafts, and join article discussions.'
                : tab === 'register'
                  ? 'Create an author account to write posts and comment.'
                  : 'Claim the platform administrator account. This locks after setup.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close authentication modal"
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 flex items-center gap-1 p-1 rounded-lg bg-stone-100 dark:bg-stone-800/80">
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setError('');
            }}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'login'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('register');
              setError('');
            }}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'register'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
            }`}
          >
            Register
          </button>
          {adminUnclaimed && (
            <button
              type="button"
              onClick={() => {
                setTab('claim-admin');
                setError('');
              }}
              className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                tab === 'claim-admin'
                  ? 'bg-white dark:bg-stone-900 text-[#1E3A8A] dark:text-blue-400 shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
              }`}
            >
              Claim Admin
            </button>
          )}
        </div>

        {tab === 'claim-admin' && (
          <div className="mt-4 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 flex items-start gap-2.5 text-xs text-blue-900 dark:text-blue-200">
            <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              One-time setup: claim the Managing Editor / Admin role for moderating posts, comments,
              and registered users.
            </span>
          </div>
        )}

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {tab !== 'login' && (
            <>
              <div>
                <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  minLength={2}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Absar Ahamed"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
                  Byline Headline (optional)
                </label>
                <input
                  type="text"
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  placeholder="CSE Student & Full-Stack Builder"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Password
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 focus:outline-2 focus:outline-[#1E3A8A]"
            />
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full py-2.5 px-4 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors disabled:opacity-60"
          >
            {busy
              ? 'Please wait...'
              : tab === 'login'
                ? 'Sign In'
                : tab === 'register'
                  ? 'Create Contributor Account'
                  : 'Claim Admin & Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
}
