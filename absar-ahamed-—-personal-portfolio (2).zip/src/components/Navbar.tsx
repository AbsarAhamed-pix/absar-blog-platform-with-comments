import { Menu, Moon, PenSquare, Sun, X } from 'lucide-react';
import { useState } from 'react';
import type { PublicUser } from '../types';

export type ActivePage = 'feed' | 'article' | 'dashboard' | 'profile' | 'admin';

interface NavbarProps {
  activePage: ActivePage;
  user: PublicUser | null;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onNavigate: (page: ActivePage) => void;
  onOpenAuth: () => void;
  onOpenNewPost: () => void;
}

export function Navbar({
  activePage,
  user,
  theme,
  onToggleTheme,
  onNavigate,
  onOpenAuth,
  onOpenNewPost,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (page: ActivePage) => {
    setMobileOpen(false);
    if ((page === 'dashboard' || page === 'profile') && !user) {
      onOpenAuth();
      return;
    }
    onNavigate(page);
  };

  const linkClass = (active: boolean) =>
    `text-sm font-medium transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
      active
        ? 'border-[#1E3A8A] dark:border-blue-400 text-stone-900 dark:text-stone-100'
        : 'border-transparent text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
    }`;

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200 dark:border-stone-800 bg-[#FAF8F5]/95 dark:bg-[#0E1013]/95 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('feed')}
          className="font-serif text-xl sm:text-2xl font-semibold tracking-tight text-stone-900 dark:text-stone-100 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1E3A8A]"
        >
          Vellum Journal
        </button>

        {/* Zone 2: Clean Single-Line Nav Links */}
        <nav className="hidden md:flex items-center gap-7" aria-label="Primary">
          <button
            type="button"
            onClick={() => handleNav('feed')}
            className={linkClass(activePage === 'feed' || activePage === 'article')}
          >
            Journal
          </button>
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className={linkClass(activePage === 'dashboard')}
          >
            My Blogs
          </button>
          <button
            type="button"
            onClick={() => handleNav('profile')}
            className={linkClass(activePage === 'profile')}
          >
            {user ? user.name.split(' ')[0] : 'Profile'}
          </button>
          {user?.role === 'admin' && (
            <button
              type="button"
              onClick={() => handleNav('admin')}
              className={linkClass(activePage === 'admin')}
            >
              Moderation
            </button>
          )}
        </nav>

        {/* Zone 3: Theme Toggle + 1 Primary CTA */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
            className="p-2 rounded-lg border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors shrink-0"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {user ? (
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenNewPost();
              }}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors whitespace-nowrap shrink-0"
            >
              <PenSquare className="w-4 h-4" />
              Write Story
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setMobileOpen(false);
                onOpenAuth();
              }}
              className="hidden sm:inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-white text-white dark:text-stone-900 transition-colors whitespace-nowrap shrink-0"
            >
              Sign In
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden p-2 rounded-lg border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-200"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-stone-200 dark:border-stone-800 bg-[#FAF8F5] dark:bg-[#0E1013] px-4 py-4 space-y-2">
          <button
            type="button"
            onClick={() => handleNav('feed')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-stone-800 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            Journal
          </button>
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-stone-800 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            My Blogs
          </button>
          <button
            type="button"
            onClick={() => handleNav('profile')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-stone-800 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            Profile
          </button>
          {user?.role === 'admin' && (
            <button
              type="button"
              onClick={() => handleNav('admin')}
              className="block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-stone-800 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
            >
              Moderation Console
            </button>
          )}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800">
            {user ? (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenNewPost();
                }}
                className="w-full py-2.5 px-4 rounded-lg text-sm font-medium bg-[#1E3A8A] text-white"
              >
                Write Story
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenAuth();
                }}
                className="w-full py-2.5 px-4 rounded-lg text-sm font-medium bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900"
              >
                Sign In / Register
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
