import { useState } from 'react';
import { BookOpen } from 'lucide-react';

interface CoverImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function CoverImage({ src, alt, className = 'w-full h-full object-cover' }: CoverImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-200 via-stone-100 to-stone-200 dark:from-stone-800 dark:via-stone-900 dark:to-stone-800 text-stone-500 dark:text-stone-400 p-6 text-center">
        <BookOpen className="w-7 h-7 mb-2 opacity-70" />
        <span className="text-xs font-medium max-w-[220px] line-clamp-2">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
