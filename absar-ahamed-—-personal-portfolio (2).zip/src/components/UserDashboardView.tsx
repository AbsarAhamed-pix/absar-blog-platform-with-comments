import { useEffect, useMemo, useState } from 'react';
import { BookOpen, Edit3, FileText, MessageSquare, PenSquare, Send, Trash2 } from 'lucide-react';
import { api } from '../lib/api';
import {
  formatEditorialDate,
  type BlogPost,
  type PublicUser,
  type RecentReceivedComment,
} from '../types';
import { ConfirmDialog } from './ConfirmDialog';

interface UserDashboardViewProps {
  token: string;
  user: PublicUser;
  refreshKey: number;
  onNewPost: () => void;
  onEditPost: (post: BlogPost) => void;
  onOpenPost: (postId: string) => void;
  onNotify: (message: string, isError?: boolean) => void;
}

export function UserDashboardView({
  token,
  user,
  refreshKey,
  onNewPost,
  onEditPost,
  onOpenPost,
  onNotify,
}: UserDashboardViewProps) {
  const [myPosts, setMyPosts] = useState<BlogPost[]>([]);
  const [recentComments, setRecentComments] = useState<RecentReceivedComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'all' | 'published' | 'draft'>('all');
  const [deleteTarget, setDeleteTarget] = useState<BlogPost | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([api.listPosts({ scope: 'mine', sort: 'latest' }, token), api.getMe(token)])
      .then(([postsRes, meRes]) => {
        if (!active) return;
        setMyPosts(postsRes.posts);
        setRecentComments(meRes.recentComments);
      })
      .catch((err) => {
        if (!active) return;
        onNotify(err instanceof Error ? err.message : 'Could not load your studio.', true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [token, refreshKey, onNotify]);

  const publishedCount = useMemo(
    () => myPosts.filter((p) => p.status === 'published').length,
    [myPosts],
  );
  const draftCount = useMemo(
    () => myPosts.filter((p) => p.status === 'draft').length,
    [myPosts],
  );
  const totalCommentsReceived = useMemo(
    () => myPosts.reduce((sum, p) => sum + p.commentCount, 0),
    [myPosts],
  );

  const visiblePosts = useMemo(() => {
    if (tab === 'all') return myPosts;
    return myPosts.filter((p) => p.status === tab);
  }, [myPosts, tab]);

  const handleTogglePublish = async (post: BlogPost) => {
    const nextStatus = post.status === 'published' ? 'draft' : 'published';
    try {
      const res = await api.updatePost(
        post.id,
        {
          title: post.title,
          excerpt: post.excerpt,
          content: post.content,
          coverImage: post.coverImage,
          category: post.category,
          tags: post.tags,
          status: nextStatus,
        },
        token,
      );
      setMyPosts((prev) => prev.map((p) => (p.id === post.id ? res.post : p)));
      onNotify(
        nextStatus === 'published' ? 'Essay published to journal.' : 'Moved back to drafts.',
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Status update failed.', true);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleteBusy(true);
    try {
      await api.deletePost(deleteTarget.id, token);
      setMyPosts((prev) => prev.filter((p) => p.id !== deleteTarget.id));
      setDeleteTarget(null);
      onNotify('Blog post deleted.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Could not delete post.', true);
    } finally {
      setDeleteBusy(false);
    }
  };

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-stone-200 dark:border-stone-800">
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-stone-500 dark:text-stone-400">
            Author Workspace
          </p>
          <h1 className="mt-2 font-serif text-3xl sm:text-4xl font-medium text-stone-900 dark:text-stone-100">
            {user.name}&apos;s Writing Studio
          </h1>
        </div>
        <button
          type="button"
          onClick={onNewPost}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg bg-[#1E3A8A] hover:bg-[#172D6B] dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors whitespace-nowrap shrink-0"
        >
          <PenSquare className="w-4 h-4" />
          Create New Blog
        </button>
      </div>

      {/* KPI Metrics Grid */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
            <span>Published Posts</span>
            <BookOpen className="w-4 h-4" />
          </div>
          <p className="mt-3 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
            {publishedCount}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
            <span>Draft Posts</span>
            <FileText className="w-4 h-4" />
          </div>
          <p className="mt-3 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
            {draftCount}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
            <span>Comments Received</span>
            <MessageSquare className="w-4 h-4" />
          </div>
          <p className="mt-3 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
            {totalCommentsReceived}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
            <span>Total Stories</span>
            <Send className="w-4 h-4" />
          </div>
          <p className="mt-3 font-serif text-3xl font-semibold text-stone-900 dark:text-stone-100 tabular-nums">
            {myPosts.length}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* My Blogs List */}
        <section className="lg:col-span-8 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100">
              My Blogs
            </h2>
            <div className="flex items-center gap-1 p-1 rounded-lg bg-stone-100 dark:bg-stone-800/80">
              {(['all', 'published', 'draft'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTab(t)}
                  className={`px-3 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
                    tab === t
                      ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="p-8 text-center text-sm text-stone-500 dark:text-stone-400 border border-stone-200 dark:border-stone-800 rounded-xl bg-white dark:bg-[#16191E]">
              Loading your stories...
            </div>
          ) : visiblePosts.length === 0 ? (
            <div className="p-10 text-center border border-stone-200 dark:border-stone-800 rounded-xl bg-white dark:bg-[#16191E]">
              <p className="font-serif text-xl text-stone-900 dark:text-stone-100">
                No {tab === 'all' ? '' : tab} posts yet
              </p>
              <p className="mt-1.5 text-sm text-stone-500 dark:text-stone-400">
                Start drafting a new essay to build your publication portfolio.
              </p>
              <button
                type="button"
                onClick={onNewPost}
                className="mt-4 px-4 py-2 text-sm font-medium rounded-lg bg-[#1E3A8A] text-white"
              >
                Create New Blog
              </button>
            </div>
          ) : (
            <div className="divide-y divide-stone-200 dark:divide-stone-800 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E]">
              {visiblePosts.map((post) => (
                <div key={post.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="min-w-0 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-stone-400 tabular-nums">
                      <span
                        className={`font-medium ${
                          post.status === 'published'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {post.status === 'published' ? 'Published' : 'Draft'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{post.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatEditorialDate(post.publishedAt || post.updatedAt)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{post.commentCount} comments</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenPost(post.id)}
                      className="text-left block"
                    >
                      <h3 className="font-serif text-lg font-medium text-stone-900 dark:text-stone-100 hover:text-[#1E3A8A] dark:hover:text-blue-400 transition-colors">
                        {post.title}
                      </h3>
                    </button>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePublish(post)}
                      className="px-3 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 whitespace-nowrap"
                    >
                      {post.status === 'published' ? 'Unpublish' : 'Publish'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onEditPost(post)}
                      aria-label={`Edit ${post.title}`}
                      className="p-2 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(post)}
                      aria-label={`Delete ${post.title}`}
                      className="p-2 rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Recent Comments Received */}
        <aside className="lg:col-span-4 space-y-4">
          <h2 className="font-serif text-2xl font-medium text-stone-900 dark:text-stone-100">
            Comments Received
          </h2>
          <div className="rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-[#16191E] divide-y divide-stone-200 dark:divide-stone-800">
            {recentComments.length === 0 ? (
              <p className="p-5 text-sm text-stone-500 dark:text-stone-400">
                Reader comments on your published stories will appear here.
              </p>
            ) : (
              recentComments.slice(0, 8).map((cmt) => (
                <div key={cmt.id} className="p-4 space-y-1.5">
                  <div className="flex items-center justify-between gap-2 text-xs text-stone-500 dark:text-stone-400">
                    <span className="font-medium text-stone-900 dark:text-stone-100">
                      {cmt.authorName}
                    </span>
                    <span className="tabular-nums">{formatEditorialDate(cmt.createdAt)}</span>
                  </div>
                  <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2">
                    &ldquo;{cmt.content}&rdquo;
                  </p>
                  <button
                    type="button"
                    onClick={() => onOpenPost(cmt.postId)}
                    className="text-xs font-medium text-[#1E3A8A] dark:text-blue-400 hover:underline text-left line-clamp-1"
                  >
                    On: {cmt.postTitle}
                  </button>
                </div>
              ))
            )}
          </div>
        </aside>
      </div>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete Blog Post"
        description={`Confirm permanent removal of "${deleteTarget?.title || ''}" and its comments?`}
        confirmLabel="Delete Post"
        busy={deleteBusy}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleConfirmDelete}
      />
    </main>
  );
}
