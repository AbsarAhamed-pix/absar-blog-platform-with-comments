export type UserRole = 'user' | 'admin';

export type BlogCategory =
  | 'Engineering'
  | 'Architecture'
  | 'Design Systems'
  | 'Databases'
  | 'Career';

export type PostStatus = 'draft' | 'published';

export type ModerationStatus = 'approved' | 'flagged';

export const BLOG_CATEGORIES: ReadonlyArray<'All' | BlogCategory> = [
  'All',
  'Engineering',
  'Architecture',
  'Design Systems',
  'Databases',
  'Career',
];

export const STUDIO_COVER_PRESETS: ReadonlyArray<{ label: string; url: string }> = [
  {
    label: 'Architectural Studio Desk',
    url: '/src/assets/images/blog_cover_architecture_1795522143267.jpg',
  },
  {
    label: 'Systems & Glass Prisms',
    url: '/src/assets/images/blog_cover_systems_1795522143794.jpg',
  },
  {
    label: 'Typographic Grid Desk',
    url: '/src/assets/images/blog_cover_typography_1795522144580.jpg',
  },
  {
    label: 'Archival Database Drawers',
    url: '/src/assets/images/blog_cover_databases_1795522144590.jpg',
  },
  {
    label: 'University Study Desk',
    url: '/src/assets/images/blog_cover_craft_1795522144973.jpg',
  },
];

export interface PublicUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  headline: string;
  bio: string;
  location: string;
  website: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: BlogCategory;
  tags: string[];
  authorId: string;
  authorName: string;
  authorHeadline: string;
  status: PostStatus;
  moderationStatus: ModerationStatus;
  moderationNote: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
  commentCount: number;
  readMinutes: number;
}

export interface BlogComment {
  id: string;
  postId: string;
  userId: string;
  authorName: string;
  authorRole: UserRole;
  parentCommentId: string | null;
  content: string;
  isModerated: boolean;
  moderationNote: string;
  createdAt: string;
  updatedAt: string;
}

export interface RecentReceivedComment extends BlogComment {
  postTitle: string;
}

export interface AdminUserSummary extends PublicUser {
  publishedCount: number;
  draftCount: number;
  commentCount: number;
}

export interface AdminOverviewData {
  users: AdminUserSummary[];
  posts: BlogPost[];
  comments: RecentReceivedComment[];
}

export function formatEditorialDate(iso: string | null): string {
  if (!iso) return 'Draft';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}
